import type { Movie, Series, Season, Episode, Genre, Category, AppSettings, User } from '@/types';

class LocalStorageService {
  private readonly STORAGE_KEYS = {
    MOVIES: 'flmks_movies',
    SERIES: 'flmks_series',
    SEASONS: 'flmks_seasons',
    EPISODES: 'flmks_episodes',
    GENRES: 'flmks_genres',
    CATEGORIES: 'flmks_categories',
    SETTINGS: 'app_settings',
    USERS: 'flmks_users',
    CURRENT_USER: 'flmks_current_user',
  };

  // Movies
  getMovies(): Movie[] {
    try {
      const data = localStorage.getItem(this.STORAGE_KEYS.MOVIES);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Error loading movies:', error);
      return [];
    }
  }

  saveMovies(movies: Movie[]): void {
    try {
      localStorage.setItem(this.STORAGE_KEYS.MOVIES, JSON.stringify(movies));
    } catch (error) {
      console.error('Error saving movies:', error);
    }
  }

  addMovie(movie: Movie): void {
    const movies = this.getMovies();
    movies.push(movie);
    this.saveMovies(movies);
  }

  updateMovie(id: string, updates: Partial<Movie>): void {
    const movies = this.getMovies();
    const index = movies.findIndex(m => m.id === id);
    if (index !== -1) {
      movies[index] = { ...movies[index], ...updates, updatedAt: new Date().toISOString() };
      this.saveMovies(movies);
    }
  }

  deleteMovie(id: string): void {
    const movies = this.getMovies();
    const filtered = movies.filter(m => m.id !== id);
    this.saveMovies(filtered);
  }

  getMovieById(id: string): Movie | null {
    const movies = this.getMovies();
    return movies.find(m => m.id === id) || null;
  }

  getMovieByTmdbId(tmdbId: number): Movie | null {
    const movies = this.getMovies();
    return movies.find(m => m.tmdbId === tmdbId) || null;
  }

  getFeaturedMovies(): Movie[] {
    const movies = this.getMovies();
    return movies.filter(m => m.isFeatured);
  }

  // Series
  getSeries(): Series[] {
    try {
      const data = localStorage.getItem(this.STORAGE_KEYS.SERIES);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Error loading series:', error);
      return [];
    }
  }

  saveSeries(series: Series[]): void {
    try {
      localStorage.setItem(this.STORAGE_KEYS.SERIES, JSON.stringify(series));
    } catch (error) {
      console.error('Error saving series:', error);
    }
  }

  addSeries(series: Series): void {
    const allSeries = this.getSeries();
    allSeries.push(series);
    this.saveSeries(allSeries);
  }

  updateSeries(id: string, updates: Partial<Series>): void {
    const allSeries = this.getSeries();
    const index = allSeries.findIndex(s => s.id === id);
    if (index !== -1) {
      allSeries[index] = { ...allSeries[index], ...updates, updatedAt: new Date().toISOString() };
      this.saveSeries(allSeries);
    }
  }

  deleteSeries(id: string): void {
    const allSeries = this.getSeries();
    const filtered = allSeries.filter(s => s.id !== id);
    this.saveSeries(filtered);
  }

  getSeriesById(id: string): Series | null {
    const allSeries = this.getSeries();
    return allSeries.find(s => s.id === id) || null;
  }

  getSeriesByTmdbId(tmdbId: number): Series | null {
    const allSeries = this.getSeries();
    return allSeries.find(s => s.tmdbId === tmdbId) || null;
  }

  getFeaturedSeries(): Series[] {
    const allSeries = this.getSeries();
    return allSeries.filter(s => s.isFeatured);
  }

  // Seasons
  getSeasons(): Season[] {
    try {
      const data = localStorage.getItem(this.STORAGE_KEYS.SEASONS);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Error loading seasons:', error);
      return [];
    }
  }

  saveSeasons(seasons: Season[]): void {
    try {
      localStorage.setItem(this.STORAGE_KEYS.SEASONS, JSON.stringify(seasons));
    } catch (error) {
      console.error('Error saving seasons:', error);
    }
  }

  addSeason(season: Season): void {
    const seasons = this.getSeasons();
    seasons.push(season);
    this.saveSeasons(seasons);
  }

  updateSeason(id: string, updates: Partial<Season>): void {
    const seasons = this.getSeasons();
    const index = seasons.findIndex(s => s.id === id);
    if (index !== -1) {
      seasons[index] = { ...seasons[index], ...updates, updatedAt: new Date().toISOString() };
      this.saveSeasons(seasons);
    }
  }

  deleteSeason(id: string): void {
    const seasons = this.getSeasons();
    const filtered = seasons.filter(s => s.id !== id);
    this.saveSeasons(filtered);
  }

  getSeasonsBySeriesId(seriesId: string): Season[] {
    const seasons = this.getSeasons();
    return seasons.filter(s => s.seriesId === seriesId).sort((a, b) => a.seasonNumber - b.seasonNumber);
  }

  getSeasonById(id: string): Season | null {
    const seasons = this.getSeasons();
    return seasons.find(s => s.id === id) || null;
  }

  // Episodes
  getEpisodes(): Episode[] {
    try {
      const data = localStorage.getItem(this.STORAGE_KEYS.EPISODES);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Error loading episodes:', error);
      return [];
    }
  }

  saveEpisodes(episodes: Episode[]): void {
    try {
      localStorage.setItem(this.STORAGE_KEYS.EPISODES, JSON.stringify(episodes));
    } catch (error) {
      console.error('Error saving episodes:', error);
    }
  }

  addEpisode(episode: Episode): void {
    const episodes = this.getEpisodes();
    episodes.push(episode);
    this.saveEpisodes(episodes);
  }

  updateEpisode(id: string, updates: Partial<Episode>): void {
    const episodes = this.getEpisodes();
    const index = episodes.findIndex(e => e.id === id);
    if (index !== -1) {
      episodes[index] = { ...episodes[index], ...updates, updatedAt: new Date().toISOString() };
      this.saveEpisodes(episodes);
    }
  }

  deleteEpisode(id: string): void {
    const episodes = this.getEpisodes();
    const filtered = episodes.filter(e => e.id !== id);
    this.saveEpisodes(filtered);
  }

  getEpisodesBySeasonId(seasonId: string): Episode[] {
    const episodes = this.getEpisodes();
    return episodes.filter(e => e.seasonId === seasonId).sort((a, b) => a.episodeNumber - b.episodeNumber);
  }

  getEpisodeById(id: string): Episode | null {
    const episodes = this.getEpisodes();
    return episodes.find(e => e.id === id) || null;
  }

  // Genres
  getGenres(): Genre[] {
    try {
      const data = localStorage.getItem(this.STORAGE_KEYS.GENRES);
      if (data) {
        return JSON.parse(data);
      }
      // Default genres
      const defaultGenres: Genre[] = [
        { id: '1', name: 'أكشن', slug: 'action', type: 'both', createdAt: new Date().toISOString() },
        { id: '2', name: 'مغامرة', slug: 'adventure', type: 'both', createdAt: new Date().toISOString() },
        { id: '3', name: 'رعب', slug: 'horror', type: 'both', createdAt: new Date().toISOString() },
        { id: '4', name: 'كوميدي', slug: 'comedy', type: 'both', createdAt: new Date().toISOString() },
        { id: '5', name: 'دراما', slug: 'drama', type: 'both', createdAt: new Date().toISOString() },
        { id: '6', name: 'خيال علمي', slug: 'sci-fi', type: 'both', createdAt: new Date().toISOString() },
        { id: '7', name: 'جريمة', slug: 'crime', type: 'both', createdAt: new Date().toISOString() },
        { id: '8', name: 'غموض', slug: 'mystery', type: 'both', createdAt: new Date().toISOString() },
        { id: '9', name: 'رومانسي', slug: 'romance', type: 'both', createdAt: new Date().toISOString() },
        { id: '10', name: 'فانتازيا', slug: 'fantasy', type: 'both', createdAt: new Date().toISOString() },
      ];
      this.saveGenres(defaultGenres);
      return defaultGenres;
    } catch (error) {
      console.error('Error loading genres:', error);
      return [];
    }
  }

  saveGenres(genres: Genre[]): void {
    try {
      localStorage.setItem(this.STORAGE_KEYS.GENRES, JSON.stringify(genres));
    } catch (error) {
      console.error('Error saving genres:', error);
    }
  }

  addGenre(genre: Genre): void {
    const genres = this.getGenres();
    genres.push(genre);
    this.saveGenres(genres);
  }

  updateGenre(id: string, updates: Partial<Genre>): void {
    const genres = this.getGenres();
    const index = genres.findIndex(g => g.id === id);
    if (index !== -1) {
      genres[index] = { ...genres[index], ...updates };
      this.saveGenres(genres);
    }
  }

  deleteGenre(id: string): void {
    const genres = this.getGenres();
    const filtered = genres.filter(g => g.id !== id);
    this.saveGenres(filtered);
  }

  // Settings
  getSettings(): AppSettings {
    try {
      const data = localStorage.getItem(this.STORAGE_KEYS.SETTINGS);
      if (data) {
        return JSON.parse(data);
      }
      // Default settings
      const defaultSettings: AppSettings = {
        tmdbApiKey: '',
        siteName: 'أفلاميكوز',
        siteDescription: 'أفلاميكوز - أفضل موقع لمشاهدة الأفلام والمسلسلات العربية والأجنبية المترجمة',
        siteKeywords: ['أفلام', 'مسلسلات', 'أفلام اون لاين', 'مسلسلات اون لاين', 'مشاهدة', 'تحميل'],
        enableAds: true,
        clickaduCode: '',
        primaryColor: '#dc2626',
        enableRegistration: true,
      };
      this.saveSettings(defaultSettings);
      return defaultSettings;
    } catch (error) {
      console.error('Error loading settings:', error);
      // Return minimal default settings
      return {
        tmdbApiKey: '',
        siteName: 'أفلاميكوز',
        siteDescription: '',
        siteKeywords: [],
        enableAds: false,
        clickaduCode: '',
        primaryColor: '#dc2626',
        enableRegistration: true,
      };
    }
  }

  saveSettings(settings: AppSettings): void {
    try {
      localStorage.setItem(this.STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (error) {
      console.error('Error saving settings:', error);
    }
  }

  updateSettings(updates: Partial<AppSettings>): void {
    const settings = this.getSettings();
    const updated = { ...settings, ...updates };
    this.saveSettings(updated);
  }

  // Users
  getUsers(): User[] {
    try {
      const data = localStorage.getItem(this.STORAGE_KEYS.USERS);
      if (data) {
        return JSON.parse(data);
      }
      // Create default admin user
      const defaultUsers: User[] = [
        {
          id: '1',
          username: 'admin',
          email: 'admin@aflamix.com',
          role: 'admin',
          createdAt: new Date().toISOString(),
        },
      ];
      this.saveUsers(defaultUsers);
      return defaultUsers;
    } catch (error) {
      console.error('Error loading users:', error);
      return [];
    }
  }

  saveUsers(users: User[]): void {
    try {
      localStorage.setItem(this.STORAGE_KEYS.USERS, JSON.stringify(users));
    } catch (error) {
      console.error('Error saving users:', error);
    }
  }

  // Current User Session
  getCurrentUser(): User | null {
    try {
      const data = localStorage.getItem(this.STORAGE_KEYS.CURRENT_USER);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Error loading current user:', error);
      return null;
    }
  }

  setCurrentUser(user: User | null): void {
    try {
      if (user) {
        localStorage.setItem(this.STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
      } else {
        localStorage.removeItem(this.STORAGE_KEYS.CURRENT_USER);
      }
    } catch (error) {
      console.error('Error setting current user:', error);
    }
  }

  // Authentication
  authenticate(username: string, password: string): User | null {
    const users = this.getUsers();
    // Simple authentication (in production, use hashed passwords)
    const user = users.find(u => u.username === username);
    if (user && password === 'admin123') { // Default password for admin
      this.setCurrentUser(user);
      return user;
    }
    return null;
  }

  logout(): void {
    this.setCurrentUser(null);
  }

  isAuthenticated(): boolean {
    return this.getCurrentUser() !== null;
  }

  // Search functionality
  searchContent(query: string, type: 'all' | 'movie' | 'series' = 'all'): { movies: Movie[]; series: Series[] } {
    const movies = this.getMovies();
    const series = this.getSeries();
    
    const lowerQuery = query.toLowerCase();
    
    const filteredMovies = type === 'all' || type === 'movie'
      ? movies.filter(m => 
          m.title.toLowerCase().includes(lowerQuery) ||
          m.overview.toLowerCase().includes(lowerQuery) ||
          m.genres.some(g => g.toLowerCase().includes(lowerQuery))
        )
      : [];
    
    const filteredSeries = type === 'all' || type === 'series'
      ? series.filter(s => 
          s.name.toLowerCase().includes(lowerQuery) ||
          s.overview.toLowerCase().includes(lowerQuery) ||
          s.genres.some(g => g.toLowerCase().includes(lowerQuery))
        )
      : [];
    
    return { movies: filteredMovies, series: filteredSeries };
  }

  // Get featured content
  getFeaturedContent(): (Movie | Series)[] {
    const featuredMovies = this.getFeaturedMovies();
    const featuredSeries = this.getFeaturedSeries();
    return [...featuredMovies, ...featuredSeries];
  }

  // Clear all data (for development/testing)
  clearAllData(): void {
    Object.values(this.STORAGE_KEYS).forEach(key => {
      localStorage.removeItem(key);
    });
  }

  // Get statistics
  getStatistics(): {
    totalMovies: number;
    totalSeries: number;
    totalSeasons: number;
    totalEpisodes: number;
    featuredMovies: number;
    featuredSeries: number;
  } {
    const movies = this.getMovies();
    const series = this.getSeries();
    const seasons = this.getSeasons();
    const episodes = this.getEpisodes();

    return {
      totalMovies: movies.length,
      totalSeries: series.length,
      totalSeasons: seasons.length,
      totalEpisodes: episodes.length,
      featuredMovies: movies.filter(m => m.isFeatured).length,
      featuredSeries: series.filter(s => s.isFeatured).length,
    };
  }
}

export default new LocalStorageService();
