import axios, { AxiosInstance } from 'axios';
import type {
  TMDBMovie,
  TMDBSeries,
  TMDBGenre,
  TMDBCast,
  TMDBCrew,
  TMDBSeason,
  TMDBEpisode,
  TMDBVideo,
  PaginatedResponse,
} from '@/types';

class TMDBService {
  private api: AxiosInstance;
  private apiKey: string = '';

  constructor() {
    this.api = axios.create({
      baseURL: 'https://api.themoviedb.org/3',
      timeout: 10000,
    });

    // Load API key from localStorage
    this.loadApiKey();
  }

  private loadApiKey(): void {
    try {
      const settings = localStorage.getItem('app_settings');
      if (settings) {
        const parsed = JSON.parse(settings);
        this.apiKey = parsed.tmdbApiKey || '';
      }
    } catch (error) {
      console.error('Error loading API key:', error);
    }
  }

  setApiKey(key: string): void {
    this.apiKey = key;
    // Save to localStorage
    try {
      const settings = localStorage.getItem('app_settings');
      const parsed = settings ? JSON.parse(settings) : {};
      parsed.tmdbApiKey = key;
      localStorage.setItem('app_settings', JSON.stringify(parsed));
    } catch (error) {
      console.error('Error saving API key:', error);
    }
  }

  getApiKey(): string {
    return this.apiKey;
  }

  private async request<T>(endpoint: string, params: Record<string, any> = {}): Promise<T> {
    if (!this.apiKey) {
      throw new Error('API Key not configured. Please set your TMDB API key in settings.');
    }

    try {
      const response = await this.api.get<T>(endpoint, {
        params: {
          api_key: this.apiKey,
          ...params,
        },
      });
      return response.data;
    } catch (error: any) {
      if (error.response?.status === 401) {
        throw new Error('Invalid API Key. Please check your TMDB API key.');
      }
      if (error.response?.status === 404) {
        throw new Error('Content not found.');
      }
      throw new Error(`TMDB API Error: ${error.message}`);
    }
  }

  // Configuration
  async getConfiguration(): Promise<any> {
    return this.request('/configuration');
  }

  // Genres
  async getMovieGenres(): Promise<{ genres: TMDBGenre[] }> {
    return this.request('/genre/movie/list');
  }

  async getTVGenres(): Promise<{ genres: TMDBGenre[] }> {
    return this.request('/genre/tv/list');
  }

  // Movies
  async getPopularMovies(page: number = 1): Promise<PaginatedResponse<TMDBMovie>> {
    return this.request('/movie/popular', { page });
  }

  async getTopRatedMovies(page: number = 1): Promise<PaginatedResponse<TMDBMovie>> {
    return this.request('/movie/top_rated', { page });
  }

  async getNowPlayingMovies(page: number = 1): Promise<PaginatedResponse<TMDBMovie>> {
    return this.request('/movie/now_playing', { page });
  }

  async getUpcomingMovies(page: number = 1): Promise<PaginatedResponse<TMDBMovie>> {
    return this.request('/movie/upcoming', { page });
  }

  async getMovieDetails(movieId: number): Promise<any> {
    return this.request(`/movie/${movieId}`, {
      append_to_response: 'credits,videos,images,recommendations,similar',
    });
  }

  async searchMovies(query: string, page: number = 1): Promise<PaginatedResponse<TMDBMovie>> {
    return this.request('/search/movie', { query, page });
  }

  async getMoviesByGenre(genreId: number, page: number = 1): Promise<PaginatedResponse<TMDBMovie>> {
    return this.request('/discover/movie', { with_genres: genreId, page });
  }

  // TV Series
  async getPopularTVShows(page: number = 1): Promise<PaginatedResponse<TMDBSeries>> {
    return this.request('/tv/popular', { page });
  }

  async getTopRatedTVShows(page: number = 1): Promise<PaginatedResponse<TMDBSeries>> {
    return this.request('/tv/top_rated', { page });
  }

  async getAiringTodayTVShows(page: number = 1): Promise<PaginatedResponse<TMDBSeries>> {
    return this.request('/tv/airing_today', { page });
  }

  async getOnTheAirTVShows(page: number = 1): Promise<PaginatedResponse<TMDBSeries>> {
    return this.request('/tv/on_the_air', { page });
  }

  async getTVShowDetails(tvId: number): Promise<any> {
    return this.request(`/tv/${tvId}`, {
      append_to_response: 'credits,videos,images,recommendations,similar,seasons',
    });
  }

  async searchTVShows(query: string, page: number = 1): Promise<PaginatedResponse<TMDBSeries>> {
    return this.request('/search/tv', { query, page });
  }

  async getTVShowsByGenre(genreId: number, page: number = 1): Promise<PaginatedResponse<TMDBSeries>> {
    return this.request('/discover/tv', { with_genres: genreId, page });
  }

  // Seasons and Episodes
  async getTVSeason(tvId: number, seasonNumber: number): Promise<any> {
    return this.request(`/tv/${tvId}/season/${seasonNumber}`, {
      append_to_response: 'credits,videos,images',
    });
  }

  async getTVEpisode(tvId: number, seasonNumber: number, episodeNumber: number): Promise<any> {
    return this.request(`/tv/${tvId}/season/${seasonNumber}/episode/${episodeNumber}`, {
      append_to_response: 'credits,videos,images',
    });
  }

  // Trending
  async getTrending(mediaType: 'all' | 'movie' | 'tv' | 'person', timeWindow: 'day' | 'week', page: number = 1): Promise<any> {
    return this.request(`/trending/${mediaType}/${time_window}`, { page });
  }

  // Search
  async searchMulti(query: string, page: number = 1): Promise<any> {
    return this.request('/search/multi', { query, page });
  }

  // Helper methods for image URLs
  getImageUrl(path: string, size: string = 'w500'): string {
    if (!path) return '/placeholder.jpg';
    return `https://image.tmdb.org/t/p/${size}${path}`;
  }

  getBackdropUrl(path: string, size: string = 'w1280'): string {
    if (!path) return '/placeholder-backdrop.jpg';
    return `https://image.tmdb.org/t/p/${size}${path}`;
  }

  getProfileUrl(path: string, size: string = 'w185'): string {
    if (!path) return '/placeholder-profile.jpg';
    return `https://image.tmdb.org/t/p/${size}${path}`;
  }

  // YouTube URL
  getYouTubeUrl(key: string): string {
    return `https://www.youtube.com/embed/${key}`;
  }

  // Import movie from TMDB
  async importMovieFromTMDB(tmdbId: number, isFeatured: boolean = false): Promise<any> {
    try {
      const tmdbData = await this.getMovieDetails(tmdbId);
      
      const newMovie = {
        id: `movie_${Date.now()}`,
        tmdbId: tmdbData.id,
        title: tmdbData.title,
        overview: tmdbData.overview,
        posterPath: tmdbData.poster_path,
        backdropPath: tmdbData.backdrop_path,
        releaseDate: tmdbData.release_date,
        rating: tmdbData.vote_average,
        voteCount: tmdbData.vote_count,
        genres: tmdbData.genres?.map((g: any) => g.name) || [],
        cast: tmdbData.credits?.cast?.slice(0, 10).map((c: any) => ({
          id: c.id,
          name: c.name,
          character: c.character,
          profilePath: c.profile_path,
          order: c.order,
        })) || [],
        crew: tmdbData.credits?.crew?.slice(0, 5).map((c: any) => ({
          id: c.id,
          name: c.name,
          job: c.job,
          department: c.department,
          profilePath: c.profile_path,
        })) || [],
        videos: tmdbData.videos?.results?.slice(0, 5).map((v: any) => ({
          id: v.id,
          key: v.key,
          name: v.name,
          site: v.site,
          type: v.type,
          official: v.official,
          publishedAt: v.published_at,
        })) || [],
        runtime: tmdbData.runtime,
        tagline: tmdbData.tagline || '',
        homepage: tmdbData.homepage || '',
        imdbId: tmdbData.imdb_id || '',
        status: tmdbData.status || '',
        budget: tmdbData.budget || 0,
        revenue: tmdbData.revenue || 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        isFeatured,
      };

      return newMovie;
    } catch (error) {
      console.error('Error importing movie from TMDB:', error);
      throw error;
    }
  }

  // Import series from TMDB
  async importSeriesFromTMDB(tmdbId: number, isFeatured: boolean = false): Promise<any> {
    try {
      const tmdbData = await this.getTVShowDetails(tmdbId);
      
      const newSeries: any = {
        id: `series_${Date.now()}`,
        tmdbId: tmdbData.id,
        name: tmdbData.name,
        overview: tmdbData.overview,
        posterPath: tmdbData.poster_path,
        backdropPath: tmdbData.backdrop_path,
        firstAirDate: tmdbData.first_air_date,
        rating: tmdbData.vote_average,
        voteCount: tmdbData.vote_count,
        genres: tmdbData.genres?.map((g: any) => g.name) || [],
        cast: tmdbData.credits?.cast?.slice(0, 10).map((c: any) => ({
          id: c.id,
          name: c.name,
          character: c.character,
          profilePath: c.profile_path,
          order: c.order,
        })) || [],
        crew: tmdbData.credits?.crew?.slice(0, 5).map((c: any) => ({
          id: c.id,
          name: c.name,
          job: c.job,
          department: c.department,
          profilePath: c.profile_path,
        })) || [],
        videos: tmdbData.videos?.results?.slice(0, 5).map((v: any) => ({
          id: v.id,
          key: v.key,
          name: v.name,
          site: v.site,
          type: v.type,
          official: v.official,
          publishedAt: v.published_at,
        })) || [],
        numberOfSeasons: tmdbData.number_of_seasons || 0,
        numberOfEpisodes: tmdbData.number_of_episodes || 0,
        homepage: tmdbData.homepage || '',
        imdbId: tmdbData.external_ids?.imdb_id || '',
        status: tmdbData.status || '',
        tagline: tmdbData.tagline || '',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        isFeatured,
      };

      // Import seasons
      if (tmdbData.seasons) {
        for (const seasonData of tmdbData.seasons) {
          if (seasonData.season_number > 0) { // Skip season 0 (specials)
            const season: any = {
              id: `season_${Date.now()}_${seasonData.season_number}`,
              seriesId: newSeries.id,
              seasonNumber: seasonData.season_number,
              name: seasonData.name,
              overview: seasonData.overview || '',
              posterPath: seasonData.poster_path,
              airDate: seasonData.air_date || '',
              episodeCount: seasonData.episode_count || 0,
              episodes: [],
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            };
            // Note: In a real app, you'd save this to localStorage
          }
        }
      }

      return newSeries;
    } catch (error) {
      console.error('Error importing series from TMDB:', error);
      throw error;
    }
  }
}

export default new TMDBService();
