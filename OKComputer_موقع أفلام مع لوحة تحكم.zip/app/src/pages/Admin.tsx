import { useState, useEffect } from 'react';
import { Routes, Route, Link, Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import SEO from '@/components/SEO';
import { Button } from '@/components/ui/button';
import {
  LayoutDashboard,
  Film,
  Tv,
  Settings,
  LogOut,
  Users,
  Menu,
  X,
  BarChart3,
} from 'lucide-react';

// Admin Pages
import Dashboard from '@/pages/admin/Dashboard';
import MoviesAdmin from '@/pages/admin/MoviesAdmin';
import SeriesAdmin from '@/pages/admin/SeriesAdmin';
import SeasonsAdmin from '@/pages/admin/SeasonsAdmin';
import EpisodesAdmin from '@/pages/admin/EpisodesAdmin';
import CategoriesAdmin from '@/pages/admin/CategoriesAdmin';
import UsersAdmin from '@/pages/admin/UsersAdmin';
import SettingsAdmin from '@/pages/admin/SettingsAdmin';

export default function Admin() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  useEffect(() => {
    if (!user) {
      navigate('/login');
    }
  }, [user, navigate]);

  if (!user) {
    return null;
  }

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

  const navItems = [
    { path: '/admin', label: 'لوحة التحكم', icon: LayoutDashboard },
    { path: '/admin/movies', label: 'الأفلام', icon: Film },
    { path: '/admin/series', label: 'المسلسلات', icon: Tv },
    { path: '/admin/seasons', label: 'المواسم', icon: BarChart3 },
    { path: '/admin/episodes', label: 'الحلقات', icon: BarChart3 },
    { path: '/admin/categories', label: 'التصنيفات', icon: Settings },
    { path: '/admin/users', label: 'المستخدمون', icon: Users },
    { path: '/admin/settings', label: 'الإعدادات', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-background">
      <SEO 
        title="لوحة التحكم"
        description="لوحة تحكم إدارة موقع أفلاميكوز"
        type="website"
      />

      {/* Mobile Header */}
      <header className="lg:hidden fixed top-0 left-0 right-0 z-40 bg-card border-b border-border">
        <div className="flex items-center justify-between h-16 px-4">
          <Button variant="ghost" size="icon" onClick={toggleSidebar}>
            {isSidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </Button>
          <h1 className="text-lg font-semibold">لوحة التحكم</h1>
          <Button variant="ghost" size="icon" onClick={logout}>
            <LogOut className="w-5 h-5" />
          </Button>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside
          className={`fixed lg:static inset-y-0 right-0 z-50 w-64 bg-card border-l border-border transform transition-transform duration-300 lg:transform-none ${
            isSidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
          }`}
        >
          <div className="h-full flex flex-col">
            {/* Logo */}
            <div className="p-6 border-b border-border">
              <Link to="/admin" className="flex items-center gap-2">
                <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                  <LayoutDashboard className="w-6 h-6 text-primary-foreground" />
                </div>
                <span className="text-xl font-bold">
                  أفلامي<span className="text-primary">كوز</span>
                </span>
              </Link>
            </div>

            {/* Navigation */}
            <nav className="flex-1 p-4">
              <ul className="space-y-2">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = location.pathname === item.path;
                  
                  return (
                    <li key={item.path}>
                      <Link
                        to={item.path}
                        onClick={() => setIsSidebarOpen(false)}
                        className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                          isActive
                            ? 'bg-primary text-primary-foreground'
                            : 'text-foreground/70 hover:bg-secondary hover:text-foreground'
                        }`}
                      >
                        <Icon className="w-5 h-5" />
                        <span>{item.label}</span>
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </nav>

            {/* Footer */}
            <div className="p-4 border-t border-border">
              <Button
                variant="outline"
                className="w-full gap-2 justify-start"
                onClick={logout}
              >
                <LogOut className="w-5 h-5" />
                تسجيل الخروج
              </Button>
            </div>
          </div>
        </aside>

        {/* Overlay for mobile */}
        {isSidebarOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}

        {/* Main Content */}
        <main className="flex-1 lg:ml-0 min-h-screen">
          <div className="lg:pt-0 pt-16">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/movies" element={<MoviesAdmin />} />
              <Route path="/series" element={<SeriesAdmin />} />
              <Route path="/seasons" element={<SeasonsAdmin />} />
              <Route path="/episodes" element={<EpisodesAdmin />} />
              <Route path="/categories" element={<CategoriesAdmin />} />
              <Route path="/users" element={<UsersAdmin />} />
              <Route path="/settings" element={<SettingsAdmin />} />
              <Route path="*" element={<Navigate to="/admin" replace />} />
            </Routes>
          </div>
        </main>
      </div>
    </div>
  );
}
