import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useContent } from '@/context/ContentContext';
import SEO from '@/components/SEO';
import AdBanner from '@/components/AdBanner';
import Loading from '@/components/Loading';
import Error, { NotFound } from '@/components/Error';
import MovieCard from '@/components/MovieCard';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Play,
  Star,
  Clock,
  Calendar,
  User,
  Clapperboard,
  ArrowLeft,
  Share2,
  Heart,
  Film,
} from 'lucide-react';
import type { Movie } from '@/types';
import tmdbService from '@/services/tmdb';

export default function MovieDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { movies } = useContent();
  const [movie, setMovie] = useState<Movie | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const loadMovie = async () => {
      if (!id) {
        setError('معرف الفيلم غير صالح');
        setLoading(false);
        return;
      }

      // First try to find in local content
      const foundMovie = movies.find(m => m.id === id);
      if (foundMovie) {
        setMovie(foundMovie);
        setLoading(false);
        return;
      }

      setError('الفيلم غير موجود');
      setLoading(false);
    };

    loadMovie();
  }, [id, movies]);

  if (loading) {
    return <Loading fullScreen message="جاري تحميل تفاصيل الفيلم..." />;
  }

  if (error) {
    return <Error message={error} />;
  }

  if (!movie) {
    return <NotFound itemType="الفيلم" />;
  }

  const year = movie.releaseDate ? new Date(movie.releaseDate).getFullYear() : '';
  const imageUrl = movie.backdropPath
    ? tmdbService.getBackdropUrl(movie.backdropPath, 'w1280')
    : tmdbService.getImageUrl(movie.posterPath, 'w1280');
  const posterUrl = tmdbService.getImageUrl(movie.posterPath, 'w500');

  // Get similar movies (same genre)
  const similarMovies = movies
    .filter(m => m.id !== movie.id && m.genres.some(g => movie.genres.includes(g)))
    .slice(0, 6);

  return (
    <div className="min-h-screen">
      <SEO 
        title={movie.title}
        description={movie.overview}
        image={posterUrl}
        type="video.movie"
        publishedAt={movie.releaseDate}
        author={movie.crew.find(c => c.job === 'Director')?.name}
      />

      {/* Hero Section */}
      <div className="relative h-[60vh] min-h-[400px] w-full overflow-hidden">
        {/* Background Image */}
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${imageUrl})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/50 to-transparent" />

        {/* Content */}
        <div className="absolute bottom-0 left-0 right-0 p-6 md:p-12">
          <div className="max-w-7xl mx-auto">
            <Button
              variant="ghost"
              onClick={() => navigate(-1)}
              className="mb-4 gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              رجوع
            </Button>

            <div className="flex flex-col md:flex-row gap-8">
              {/* Poster */}
              <div className="flex-shrink-0">
                <img
                  src={posterUrl}
                  alt={movie.title}
                  className="w-48 md:w-64 rounded-xl shadow-2xl"
                />
              </div>

              {/* Info */}
              <div className="flex-1">
                {/* Title */}
                <h1 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
                  {movie.title}
                </h1>

                {/* Meta Info */}
                <div className="flex flex-wrap items-center gap-4 mb-6">
                  {year && (
                    <div className="flex items-center gap-1 text-foreground/80">
                      <Calendar className="w-4 h-4" />
                      <span>{year}</span>
                    </div>
                  )}

                  {movie.runtime > 0 && (
                    <div className="flex items-center gap-1 text-foreground/80">
                      <Clock className="w-4 h-4" />
                      <span>{movie.runtime} دقيقة</span>
                    </div>
                  )}

                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                    <span className="font-medium">{movie.rating.toFixed(1)}</span>
                    <span className="text-muted-foreground">({movie.voteCount})</span>
                  </div>

                  <div className="flex gap-2">
                    {movie.genres.slice(0, 3).map((genre) => (
                      <Badge key={genre} variant="secondary">
                        {genre}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Tagline */}
                {movie.tagline && (
                  <p className="text-xl text-primary italic mb-6">
                    "{movie.tagline}"
                  </p>
                )}

                {/* Overview */}
                <p className="text-foreground/80 text-lg max-w-3xl mb-6 leading-relaxed">
                  {movie.overview}
                </p>

                {/* Actions */}
                <div className="flex flex-wrap gap-3 mb-6">
                  <Link to={`/watch/movie/${movie.id}`}>
                    <Button size="lg" className="gap-2">
                      <Play className="w-5 h-5" />
                      مشاهدة الآن
                    </Button>
                  </Link>
                  <Button size="lg" variant="outline" className="gap-2">
                    <Heart className="w-5 h-5" />
                    المفضلة
                  </Button>
                  <Button size="lg" variant="outline" className="gap-2">
                    <Share2 className="w-5 h-5" />
                    مشاركة
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Ad Banner */}
      <div className="py-6 px-4">
        <div className="max-w-7xl mx-auto">
          <AdBanner type="leaderboard" />
        </div>
      </div>

      {/* Details Section */}
      <div className="py-8 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            {/* Main Info */}
            <div className="md:col-span-2 space-y-8">
              {/* Cast */}
              {movie.cast.length > 0 && (
                <section>
                  <h2 className="text-2xl font-bold text-foreground mb-4 flex items-center gap-2">
                    <User className="w-6 h-6 text-primary" />
                    الممثلون
                  </h2>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                    {movie.cast.slice(0, 6).map((actor) => (
                      <div key={actor.id} className="text-center">
                        <div className="w-16 h-16 md:w-20 md:h-20 bg-secondary rounded-full mx-auto mb-2 overflow-hidden">
                          {actor.profilePath ? (
                            <img
                              src={tmdbService.getProfileUrl(actor.profilePath)}
                              alt={actor.name}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <User className="w-8 h-8 text-muted-foreground" />
                            </div>
                          )}
                        </div>
                        <p className="text-sm font-medium text-foreground line-clamp-1">
                          {actor.name}
                        </p>
                        {actor.character && (
                          <p className="text-xs text-muted-foreground line-clamp-1">
                            {actor.character}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </section>
              )}

              {/* Crew */}
              {movie.crew.length > 0 && (
                <section>
                  <h2 className="text-2xl font-bold text-foreground mb-4 flex items-center gap-2">
                    <Clapperboard className="w-6 h-6 text-primary" />
                    فريق العمل
                  </h2>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {movie.crew.slice(0, 6).map((crew) => (
                      <div key={crew.id} className="bg-card rounded-lg p-4 border border-border">
                        <p className="font-medium text-foreground">{crew.name}</p>
                        <p className="text-sm text-muted-foreground">{crew.job}</p>
                      </div>
                    ))}
                  </div>
                </section>
              )}

              {/* Ad Banner */}
              <div className="py-4">
                <AdBanner type="rectangle" />
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Info Cards */}
              <div className="bg-card rounded-xl p-6 border border-border">
                <h3 className="font-semibold text-foreground mb-4">معلومات</h3>
                <div className="space-y-3 text-sm">
                  {movie.status && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">الحالة:</span>
                      <span className="text-foreground">{movie.status}</span>
                    </div>
                  )}
                  {movie.budget > 0 && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">الميزانية:</span>
                      <span className="text-foreground">
                        ${movie.budget.toLocaleString()}
                      </span>
                    </div>
                  )}
                  {movie.revenue > 0 && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">الإيرادات:</span>
                      <span className="text-foreground">
                        ${movie.revenue.toLocaleString()}
                      </span>
                    </div>
                  )}
                  {movie.imdbId && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">IMDB:</span>
                      <a
                        href={`https://www.imdb.com/title/${movie.imdbId}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:underline"
                      >
                        {movie.imdbId}
                      </a>
                    </div>
                  )}
                </div>
              </div>

              {/* Keywords */}
              {movie.genres.length > 0 && (
                <div className="bg-card rounded-xl p-6 border border-border">
                  <h3 className="font-semibold text-foreground mb-4">كلمات دلالية</h3>
                  <div className="flex flex-wrap gap-2">
                    {movie.genres.map((genre) => (
                      <Badge key={genre} variant="outline">
                        {genre}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Ad Banner */}
              <AdBanner type="skyscraper" />
            </div>
          </div>
        </div>
      </div>

      {/* Similar Movies */}
      {similarMovies.length > 0 && (
        <section className="py-8 px-4 bg-card/30">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center gap-2">
              <Film className="w-6 h-6 text-primary" />
              أفلام مشابهة
            </h2>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {similarMovies.map((similarMovie) => (
                <MovieCard key={similarMovie.id} movie={similarMovie} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Ad Banner */}
      <div className="py-6 px-4">
        <div className="max-w-7xl mx-auto">
          <AdBanner type="leaderboard" />
        </div>
      </div>
    </div>
  );
}
