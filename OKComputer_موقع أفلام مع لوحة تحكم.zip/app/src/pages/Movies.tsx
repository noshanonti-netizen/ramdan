import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useContent } from '@/context/ContentContext';
import SEO from '@/components/SEO';
import MovieCard from '@/components/MovieCard';
import AdBanner from '@/components/AdBanner';
import Loading from '@/components/Loading';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Film, Search, Filter, X } from 'lucide-react';
import type { Movie } from '@/types';

export default function Movies() {
  const { movies, genres, loading, searchContent } = useContent();
  const [searchParams, setSearchParams] = useSearchParams();
  const [filteredMovies, setFilteredMovies] = useState<Movie[]>([]);
  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '');
  const [selectedGenre, setSelectedGenre] = useState(searchParams.get('genre') || 'all');
  const [selectedYear, setSelectedYear] = useState(searchParams.get('year') || 'all');
  const [sortBy, setSortBy] = useState(searchParams.get('sort') || 'rating');
  const [showFilters, setShowFilters] = useState(false);

  // Extract unique years from movies
  const years = Array.from(
    new Set(
      movies
        .filter(m => m.releaseDate)
        .map(m => new Date(m.releaseDate).getFullYear())
        .filter(y => y > 1900 && y <= new Date().getFullYear())
    )
  ).sort((a, b) => b - a);

  // Filter movies based on search params
  useEffect(() => {
    const filters = {
      query: searchQuery,
      type: 'movie' as const,
      genres: selectedGenre === 'all' ? [] : [selectedGenre],
      year: selectedYear === 'all' ? '' : selectedYear,
      sortBy,
      page: 1,
    };

    const results = searchContent(filters) as Movie[];
    setFilteredMovies(results);

    // Update URL params
    const params = new URLSearchParams();
    if (searchQuery) params.set('q', searchQuery);
    if (selectedGenre !== 'all') params.set('genre', selectedGenre);
    if (selectedYear !== 'all') params.set('year', selectedYear);
    if (sortBy !== 'rating') params.set('sort', sortBy);
    setSearchParams(params, { replace: true });
  }, [searchQuery, selectedGenre, selectedYear, sortBy, movies, searchContent, setSearchParams]);

  if (loading && movies.length === 0) {
    return <Loading fullScreen message="جاري تحميل الأفلام..." />;
  }

  return (
    <div className="min-h-screen py-8 px-4">
      <SEO 
        title="الأفلام"
        description="تصفح مجموعة واسعة من الأفلام العربية والأجنبية المترجمة"
        type="website"
      />

      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
              <Film className="w-7 h-7 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-foreground">الأفلام</h1>
              <p className="text-muted-foreground">
                {filteredMovies.length} فيلم
              </p>
            </div>
          </div>

          <Button
            variant="outline"
            onClick={() => setShowFilters(!showFilters)}
            className="gap-2 md:hidden"
          >
            <Filter className="w-4 h-4" />
            الفلاتر
          </Button>
        </div>

        {/* Ad Banner */}
        <div className="mb-8">
          <AdBanner type="leaderboard" />
        </div>

        {/* Search and Filters */}
        <div className={`space-y-4 mb-8 ${showFilters ? 'block' : 'hidden md:block'}`}>
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="ابحث عن فيلم..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Genre Filter */}
            <Select value={selectedGenre} onValueChange={setSelectedGenre}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="التصنيف" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع التصنيفات</SelectItem>
                {genres.map((genre) => (
                  <SelectItem key={genre.id} value={genre.name}>
                    {genre.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Year Filter */}
            <Select value={selectedYear} onValueChange={setSelectedYear}>
              <SelectTrigger className="w-full md:w-36">
                <SelectValue placeholder="السنة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع السنوات</SelectItem>
                {years.slice(0, 20).map((year) => (
                  <SelectItem key={year} value={year.toString()}>
                    {year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Sort */}
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full md:w-36">
                <SelectValue placeholder="الترتيب" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="rating">الأعلى تقييماً</SelectItem>
                <SelectItem value="date">الأحدث</SelectItem>
                <SelectItem value="title">العنوان</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Active Filters */}
          {(searchQuery || selectedGenre !== 'all' || selectedYear !== 'all') && (
            <div className="flex flex-wrap gap-2">
              {searchQuery && (
                <span className="inline-flex items-center gap-1 px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">
                  بحث: {searchQuery}
                  <button onClick={() => setSearchQuery('')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              {selectedGenre !== 'all' && (
                <span className="inline-flex items-center gap-1 px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">
                  تصنيف: {selectedGenre}
                  <button onClick={() => setSelectedGenre('all')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              {selectedYear !== 'all' && (
                <span className="inline-flex items-center gap-1 px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">
                  سنة: {selectedYear}
                  <button onClick={() => setSelectedYear('all')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
            </div>
          )}
        </div>

        {/* Ad Banner */}
        <div className="mb-8">
          <AdBanner type="rectangle" />
        </div>

        {/* Movies Grid */}
        {filteredMovies.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            {filteredMovies.map((movie) => (
              <MovieCard key={movie.id} movie={movie} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <Film className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-foreground mb-2">
              لا توجد أفلام
            </h3>
            <p className="text-muted-foreground mb-4">
              لم يتم العثور على أفلام تطابق بحثك
            </p>
            <Button onClick={() => {
              setSearchQuery('');
              setSelectedGenre('all');
              setSelectedYear('all');
            }}>
              إعادة تعيين الفلاتر
            </Button>
          </div>
        )}

        {/* Ad Banner */}
        <div className="mt-12">
          <AdBanner type="leaderboard" />
        </div>
      </div>
    </div>
  );
}
