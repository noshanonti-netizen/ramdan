import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useContent } from '@/context/ContentContext';
import SEO from '@/components/SEO';
import AdBanner from '@/components/AdBanner';
import Loading from '@/components/Loading';
import MovieCard from '@/components/MovieCard';
import SeriesCard from '@/components/SeriesCard';
import { Button } from '@/components/ui/button';
import { Film, Tv, ArrowLeft } from 'lucide-react';
import type { Movie, Series } from '@/types';

export default function Category() {
  const { type, slug } = useParams<{ type: string; slug: string }>();
  const { movies, series, genres, loading } = useContent();
  const [filteredContent, setFilteredContent] = useState<(Movie | Series)[]>([]);
  const [genreInfo, setGenreInfo] = useState<any>(null);

  useEffect(() => {
    const loadCategory = () => {
      if (!type || !slug) return;

      // Find genre
      const foundGenre = genres.find(g => g.slug === slug);
      setGenreInfo(foundGenre);

      // Filter content by genre
      let results: (Movie | Series)[] = [];

      if (type === 'movies' || type === 'both') {
        const movieResults = movies.filter(m => 
          m.genres.some(g => g.toLowerCase().replace(/\s+/g, '-') === slug)
        );
        results = [...results, ...movieResults];
      }

      if (type === 'series' || type === 'both') {
        const seriesResults = series.filter(s => 
          s.genres.some(g => g.toLowerCase().replace(/\s+/g, '-') === slug)
        );
        results = [...results, ...seriesResults];
      }

      setFilteredContent(results);
    };

    loadCategory();
  }, [type, slug, movies, series, genres]);

  if (loading && movies.length === 0 && series.length === 0) {
    return <Loading fullScreen message="جاري التحميل..." />;
  }

  const title = genreInfo?.name || slug || 'تصنيف';

  return (
    <div className="min-h-screen py-8 px-4">
      <SEO 
        title={title}
        description={`تصفح ${title} في أفلاميكوز`}
        type="website"
      />

      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link to="/">
            <Button variant="ghost" className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              الرئيسية
            </Button>
          </Link>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
              {type === 'movies' ? (
                <Film className="w-7 h-7 text-primary" />
              ) : (
                <Tv className="w-7 h-7 text-primary" />
              )}
            </div>
            <div>
              <h1 className="text-3xl font-bold text-foreground">
                {title}
              </h1>
              <p className="text-muted-foreground">
                {filteredContent.length} محتوى
              </p>
            </div>
          </div>
        </div>

        {/* Ad Banner */}
        <div className="mb-8">
          <AdBanner type="leaderboard" />
        </div>

        {/* Content Grid */}
        {filteredContent.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            {filteredContent.map((item) =>
              'title' in item ? (
                <MovieCard key={item.id} movie={item} />
              ) : (
                <SeriesCard key={item.id} series={item} />
              )
            )}
          </div>
        ) : (
          <div className="text-center py-16">
            {type === 'movies' ? (
              <Film className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            ) : (
              <Tv className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            )}
            <h3 className="text-xl font-semibold text-foreground mb-2">
              لا يوجد محتوى
            </h3>
            <p className="text-muted-foreground mb-4">
              لم يتم العثور على محتوى في هذا التصنيف
            </p>
            <Link to="/">
              <Button>
                العودة للرئيسية
              </Button>
            </Link>
          </div>
        )}

        {/* Ad Banner */}
        <div className="mt-12">
          <AdBanner type="leaderboard" />
        </div>
      </div>
    </div>
  );
}
