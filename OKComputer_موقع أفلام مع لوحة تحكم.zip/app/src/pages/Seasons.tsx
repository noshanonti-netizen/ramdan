import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useContent } from '@/context/ContentContext';
import SEO from '@/components/SEO';
import AdBanner from '@/components/AdBanner';
import Loading from '@/components/Loading';
import Error, { NotFound } from '@/components/Error';
import SeasonCard from '@/components/SeasonCard';
import { Button } from '@/components/ui/button';
import { Tv, ArrowLeft, ChevronRight } from 'lucide-react';
import type { Series, Season } from '@/types';
import localStorageService from '@/services/localStorage';

export default function Seasons() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { series: allSeries } = useContent();
  const [series, setSeries] = useState<Series | null>(null);
  const [seasons, setSeasons] = useState<Season[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const loadData = async () => {
      if (!id) {
        setError('معرف المسلسل غير صالح');
        setLoading(false);
        return;
      }

      const foundSeries = allSeries.find(s => s.id === id);
      if (!foundSeries) {
        setError('المسلسل غير موجود');
        setLoading(false);
        return;
      }

      setSeries(foundSeries);
      
      // Load seasons
      const seriesSeasons = localStorageService.getSeasonsBySeriesId(foundSeries.id);
      setSeasons(seriesSeasons);
      setLoading(false);
    };

    loadData();
  }, [id, allSeries]);

  if (loading) {
    return <Loading fullScreen message="جاري تحميل المواسم..." />;
  }

  if (error) {
    return <Error message={error} />;
  }

  if (!series) {
    return <NotFound itemType="المسلسل" />;
  }

  return (
    <div className="min-h-screen py-8 px-4">
      <SEO 
        title={`${series.name} - المواسم`}
        description={`جميع مواسم مسلسل ${series.name}`}
        type="video.tv_show"
      />

      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              onClick={() => navigate(-1)}
              className="gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              رجوع
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                <Tv className="w-7 h-7 text-primary" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">
                  {series.name}
                </h1>
                <p className="text-muted-foreground">
                  {seasons.length} موسم
                </p>
              </div>
            </div>
          </div>

          <Link to={`/series/${series.id}`}>
            <Button variant="outline" className="gap-2">
              معلومات المسلسل
              <ChevronRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>

        {/* Ad Banner */}
        <div className="mb-8">
          <AdBanner type="leaderboard" />
        </div>

        {/* Seasons Grid */}
        {seasons.length > 0 ? (
          <div className="space-y-6">
            {seasons.map((season) => (
              <SeasonCard
                key={season.id}
                season={season}
                seriesId={series.id}
                seriesName={series.name}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <Tv className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-foreground mb-2">
              لا توجد مواسم
            </h3>
            <p className="text-muted-foreground mb-4">
              لم يتم إضافة مواسم لهذا المسلسل بعد
            </p>
          </div>
        )}

        {/* Ad Banner */}
        <div className="mt-12">
          <AdBanner type="leaderboard" />
        </div>
      </div>
    </div>
  );
}
