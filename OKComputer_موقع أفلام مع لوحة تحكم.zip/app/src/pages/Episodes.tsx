import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useContent } from '@/context/ContentContext';
import SEO from '@/components/SEO';
import AdBanner from '@/components/AdBanner';
import Loading from '@/components/Loading';
import Error, { NotFound } from '@/components/Error';
import EpisodeCard from '@/components/EpisodeCard';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Tv,
  ArrowLeft,
  ChevronRight,
  Calendar,
  Film,
} from 'lucide-react';
import type { Series, Season, Episode } from '@/types';
import localStorageService from '@/services/localStorage';
import tmdbService from '@/services/tmdb';

export default function Episodes() {
  const { id, seasonNumber } = useParams<{ id: string; seasonNumber: string }>();
  const navigate = useNavigate();
  const { series: allSeries } = useContent();
  const [series, setSeries] = useState<Series | null>(null);
  const [season, setSeason] = useState<Season | null>(null);
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const loadData = async () => {
      if (!id || !seasonNumber) {
        setError('المعرف غير صالح');
        setLoading(false);
        return;
      }

      const foundSeries = allSeries.find(s => s.id === id);
      if (!foundSeries) {
        setError('المسلسل غير موجود');
        setLoading(false);
        return;
      }

      setSeries(foundSeries);

      // Find season
      const seasonNum = parseInt(seasonNumber);
      const allSeasons = localStorageService.getSeasonsBySeriesId(foundSeries.id);
      const foundSeason = allSeasons.find(s => s.seasonNumber === seasonNum);
      
      if (!foundSeason) {
        setError('الموسم غير موجود');
        setLoading(false);
        return;
      }

      setSeason(foundSeason);

      // Load episodes
      const seasonEpisodes = localStorageService.getEpisodesBySeasonId(foundSeason.id);
      setEpisodes(seasonEpisodes);
      setLoading(false);
    };

    loadData();
  }, [id, seasonNumber, allSeries]);

  if (loading) {
    return <Loading fullScreen message="جاري تحميل الحلقات..." />;
  }

  if (error) {
    return <Error message={error} />;
  }

  if (!series || !season) {
    return <NotFound itemType="الموسم" />;
  }

  const imageUrl = season.posterPath
    ? tmdbService.getImageUrl(season.posterPath, 'w1280')
    : series.backdropPath
    ? tmdbService.getBackdropUrl(series.backdropPath, 'w1280')
    : tmdbService.getImageUrl(series.posterPath, 'w1280');

  return (
    <div className="min-h-screen">
      <SEO 
        title={`${series.name} - الموسم ${season.seasonNumber}`}
        description={season.overview || series.overview}
        image={tmdbService.getImageUrl(season.posterPath, 'w500')}
        type="video.tv_show"
      />

      {/* Hero Section */}
      <div className="relative h-[50vh] min-h-[300px] w-full overflow-hidden">
        {/* Background Image */}
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${imageUrl})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-transparent" />

        {/* Content */}
        <div className="absolute bottom-0 left-0 right-0 p-6 md:p-12">
          <div className="max-w-7xl mx-auto">
            <Button
              variant="ghost"
              onClick={() => navigate(-1)}
              className="mb-4 gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              رجوع
            </Button>

            <div>
              <p className="text-primary font-medium mb-2">{series.name}</p>
              <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                الموسم {season.seasonNumber}
              </h1>
              <p className="text-foreground/80 max-w-2xl mb-4">
                {season.overview || series.overview}
              </p>
              <div className="flex items-center gap-4 text-sm">
                {season.airDate && (
                  <div className="flex items-center gap-1 text-foreground/70">
                    <Calendar className="w-4 h-4" />
                    <span>{new Date(season.airDate).getFullYear()}</span>
                  </div>
                )}
                <Badge>
                  {season.episodeCount} حلقة
                </Badge>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Ad Banner */}
      <div className="py-6 px-4">
        <div className="max-w-7xl mx-auto">
          <AdBanner type="leaderboard" />
        </div>
      </div>

      {/* Episodes Section */}
      <div className="py-8 px-4">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Film className="w-6 h-6 text-primary" />
              </div>
              <h2 className="text-2xl font-bold text-foreground">
                الحلقات ({episodes.length})
              </h2>
            </div>

            <Link to={`/series/${series.id}/seasons`}>
              <Button variant="outline" className="gap-2">
                جميع المواسم
                <ChevronRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>

          {/* Ad Banner */}
          <div className="mb-8">
            <AdBanner type="rectangle" />
          </div>

          {/* Episodes Grid */}
          {episodes.length > 0 ? (
            <div className="space-y-4">
              {episodes.map((episode) => (
                <EpisodeCard
                  key={episode.id}
                  episode={episode}
                  seriesId={series.id}
                  seasonNumber={season.seasonNumber}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <Film className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-2">
                لا توجد حلقات
              </h3>
              <p className="text-muted-foreground mb-4">
                لم يتم إضافة حلقات لهذا الموسم بعد
              </p>
            </div>
          )}

          {/* Ad Banner */}
          <div className="mt-12">
            <AdBanner type="leaderboard" />
          </div>
        </div>
      </div>
    </div>
  );
}
