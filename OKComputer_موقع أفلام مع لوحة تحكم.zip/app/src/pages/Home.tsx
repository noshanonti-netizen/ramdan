import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useContent } from '@/context/ContentContext';
import SEO from '@/components/SEO';
import HeroSlider from '@/components/HeroSlider';
import MovieCard from '@/components/MovieCard';
import SeriesCard from '@/components/SeriesCard';
import AdBanner from '@/components/AdBanner';
import Loading from '@/components/Loading';
import { Button } from '@/components/ui/button';
import { Film, Tv, ArrowRight, Sparkles } from 'lucide-react';
import type { Movie, Series } from '@/types';

export default function Home() {
  const { movies, series, loading } = useContent();
  const [featuredContent, setFeaturedContent] = useState<(Movie | Series)[]>([]);

  useEffect(() => {
    // Get featured content
    const featuredMovies = movies.filter(m => m.isFeatured);
    const featuredSeries = series.filter(s => s.isFeatured);
    setFeaturedContent([...featuredMovies, ...featuredSeries]);
  }, [movies, series]);

  if (loading && movies.length === 0 && series.length === 0) {
    return <Loading fullScreen message="جاري تحميل المحتوى..." />;
  }

  return (
    <div className="min-h-screen">
      <SEO 
        title=""
        description="أفلاميكوز - أفضل موقع لمشاهدة الأفلام والمسلسلات العربية والأجنبية المترجمة بجودة عالية"
        type="website"
      />

      {/* Hero Slider */}
      {featuredContent.length > 0 && (
        <HeroSlider items={featuredContent} />
      )}

      {/* Clickadu Ad Banner - After Hero */}
      <div className="py-6 px-4">
        <div className="max-w-7xl mx-auto">
          <AdBanner type="leaderboard" />
        </div>
      </div>

      {/* Latest Movies */}
      {movies.length > 0 && (
        <section className="py-8 px-4">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Film className="w-6 h-6 text-primary" />
                </div>
                <h2 className="text-2xl font-bold text-foreground">أحدث الأفلام</h2>
              </div>
              <Link to="/movies">
                <Button variant="ghost" className="gap-2 text-primary hover:text-primary">
                  عرض الكل
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {movies.slice(0, 12).map((movie) => (
                <MovieCard key={movie.id} movie={movie} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Clickadu Ad Banner - Between Sections */}
      <div className="py-6 px-4">
        <div className="max-w-7xl mx-auto">
          <AdBanner type="rectangle" />
        </div>
      </div>

      {/* Latest Series */}
      {series.length > 0 && (
        <section className="py-8 px-4 bg-card/30">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Tv className="w-6 h-6 text-primary" />
                </div>
                <h2 className="text-2xl font-bold text-foreground">أحدث المسلسلات</h2>
              </div>
              <Link to="/series">
                <Button variant="ghost" className="gap-2 text-primary hover:text-primary">
                  عرض الكل
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {series.slice(0, 12).map((seriesItem) => (
                <SeriesCard key={seriesItem.id} series={seriesItem} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Featured Section */}
      {(movies.filter(m => m.isFeatured).length > 0 || series.filter(s => s.isFeatured).length > 0) && (
        <section className="py-8 px-4">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-primary" />
                </div>
                <h2 className="text-2xl font-bold text-foreground">محتوى مميز</h2>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {movies.filter(m => m.isFeatured).slice(0, 6).map((movie) => (
                <MovieCard key={movie.id} movie={movie} />
              ))}
              {series.filter(s => s.isFeatured).slice(0, 6).map((seriesItem) => (
                <SeriesCard key={seriesItem.id} series={seriesItem} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Empty State */}
      {movies.length === 0 && series.length === 0 && !loading && (
        <div className="py-16 px-4 text-center">
          <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <Film className="w-12 h-12 text-primary" />
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-4">
            مرحباً بك في أفلاميكوز
          </h2>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            ابدأ بإضافة المحتوى من خلال لوحة التحكم. يمكنك استيراد الأفلام والمسلسلات من TMDB أو إضافتها يدوياً.
          </p>
          <Link to="/admin">
            <Button className="gap-2">
              <Sparkles className="w-4 h-4" />
              اذهب إلى لوحة التحكم
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}
