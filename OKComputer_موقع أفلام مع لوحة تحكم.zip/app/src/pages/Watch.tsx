import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useContent } from '@/context/ContentContext';
import SEO from '@/components/SEO';
import AdBanner from '@/components/AdBanner';
import Loading from '@/components/Loading';
import Error, { NotFound } from '@/components/Error';
import { Button } from '@/components/ui/button';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  ArrowLeft,
  SkipBack,
  SkipForward,
  Settings,
} from 'lucide-react';
import type { Movie, Series, Episode } from '@/types';
import localStorageService from '@/services/localStorage';

interface WatchProps {
  type: 'movie' | 'series';
}

export default function Watch({ type }: WatchProps) {
  const navigate = useNavigate();
  const { id, seasonNumber, episodeNumber } = useParams<{
    id: string;
    seasonNumber: string;
    episodeNumber: string;
  }>();
  const { movies, series: allSeries } = useContent();
  const [content, setContent] = useState<Movie | Series | null>(null);
  const [episode, setEpisode] = useState<Episode | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [videoUrl, setVideoUrl] = useState('');

  useEffect(() => {
    const loadContent = async () => {
      if (!id) {
        setError('المعرف غير صالح');
        setLoading(false);
        return;
      }

      if (type === 'movie') {
        const foundMovie = movies.find(m => m.id === id);
        if (foundMovie) {
          setContent(foundMovie);
          // Set a sample video URL (in production, this would come from your video source)
          setVideoUrl('https://www.w3schools.com/html/mov_bbb.mp4');
        } else {
          setError('الفيلم غير موجود');
        }
      } else {
        const foundSeries = allSeries.find(s => s.id === id);
        if (!foundSeries) {
          setError('المسلسل غير موجود');
          setLoading(false);
          return;
        }

        setContent(foundSeries);

        // Load episode
        if (seasonNumber && episodeNumber) {
          const seasonNum = parseInt(seasonNumber);
          const episodeNum = parseInt(episodeNumber);

          // Find season
          const seasons = localStorageService.getSeasonsBySeriesId(foundSeries.id);
          const foundSeason = seasons.find(s => s.seasonNumber === seasonNum);

          if (foundSeason) {
            // Find episode
            const episodes = localStorageService.getEpisodesBySeasonId(foundSeason.id);
            const foundEpisode = episodes.find(e => e.episodeNumber === episodeNum);

            if (foundEpisode) {
              setEpisode(foundEpisode);
              // Set a sample video URL
              setVideoUrl('https://www.w3schools.com/html/mov_bbb.mp4');
            } else {
              setError('الحلقة غير موجودة');
            }
          } else {
            setError('الموسم غير موجود');
          }
        } else {
          setError('رقم الموسم أو الحلقة غير صالح');
        }
      }

      setLoading(false);
    };

    loadContent();
  }, [id, seasonNumber, episodeNumber, type, movies, allSeries]);

  if (loading) {
    return <Loading fullScreen message="جاري تحميل الفيديو..." />;
  }

  if (error) {
    return <Error message={error} />;
  }

  if (!content) {
    return <NotFound itemType="المحتوى" />;
  }

  const title = 'title' in content ? content.title : content.name;
  const year = 'releaseDate' in content 
    ? (content.releaseDate ? new Date(content.releaseDate).getFullYear() : '')
    : (content.firstAirDate ? new Date(content.firstAirDate).getFullYear() : '');
  const posterUrl = content.posterPath;

  return (
    <div className="min-h-screen bg-black">
      <SEO 
        title={`مشاهدة ${title}`}
        description={`مشاهدة ${title} ${year ? `(${year})` : ''} اون لاين`}
        image={posterUrl}
        type="video.movie"
      />

      {/* Video Player */}
      <div className="relative h-screen w-full bg-black">
        {/* Video Container */}
        <div className="absolute inset-0 flex items-center justify-center">
          {videoUrl ? (
            <video
              src={videoUrl}
              controls
              autoPlay
              className="w-full h-full object-contain"
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
            >
              متصفحك لا يدعم تشغيل الفيديو.
            </video>
          ) : (
            <div className="text-white text-center">
              <Play className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p>فيديو غير متوفر</p>
            </div>
          )}
        </div>

        {/* Top Bar */}
        <div className="absolute top-0 left-0 right-0 p-4 bg-gradient-to-b from-black/80 to-transparent">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              onClick={() => navigate(-1)}
              className="text-white hover:bg-white/10 gap-2"
            >
              <ArrowLeft className="w-5 h-5" />
              رجوع
            </Button>

            <div className="flex items-center gap-4">
              <Button variant="ghost" className="text-white hover:bg-white/10">
                <Settings className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Title */}
          <div className="mt-4">
            <h1 className="text-xl md:text-2xl font-bold text-white">
              {title}
              {episode && ` - الحلقة ${episode.episodeNumber}`}
            </h1>
            {episode && (
              <p className="text-white/70 text-sm mt-1">
                {episode.name}
              </p>
            )}
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                onClick={() => setIsPlaying(!isPlaying)}
                className="text-white hover:bg-white/10"
              >
                {isPlaying ? (
                  <Pause className="w-6 h-6" />
                ) : (
                  <Play className="w-6 h-6" />
                )}
              </Button>

              <Button
                variant="ghost"
                onClick={() => setIsMuted(!isMuted)}
                className="text-white hover:bg-white/10"
              >
                {isMuted ? (
                  <VolumeX className="w-5 h-5" />
                ) : (
                  <Volume2 className="w-5 h-5" />
                )}
              </Button>

              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  className="text-white hover:bg-white/10"
                >
                  <SkipBack className="w-5 h-5" />
                </Button>
                <Button
                  variant="ghost"
                  className="text-white hover:bg-white/10"
                >
                  <SkipForward className="w-5 h-5" />
                </Button>
              </div>
            </div>

            <Button
              variant="ghost"
              className="text-white hover:bg-white/10"
            >
              <Maximize className="w-5 h-5" />
            </Button>
          </div>

          {/* Progress Bar */}
          <div className="mt-4 h-1 bg-white/20 rounded-full overflow-hidden">
            <div className="h-full bg-primary w-1/3"></div>
          </div>
        </div>
      </div>

      {/* Ad Banner - Below Video */}
      <div className="py-4 px-4 bg-background">
        <div className="max-w-7xl mx-auto">
          <AdBanner type="leaderboard" />
        </div>
      </div>

      {/* Content Info */}
      <div className="py-8 px-4 bg-background">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Info */}
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-foreground mb-4">
                {title}
              </h2>

              {'overview' in content && content.overview && (
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {content.overview}
                </p>
              )}

              {episode && (
                <div className="bg-card rounded-xl p-6 border border-border">
                  <h3 className="font-semibold text-foreground mb-2">
                    {episode.name}
                  </h3>
                  {episode.overview && (
                    <p className="text-muted-foreground text-sm">
                      {episode.overview}
                    </p>
                  )}
                </div>
              )}

              {/* Navigation */}
              <div className="flex gap-3 mt-6">
                {type === 'movie' ? (
                  <Link to={`/movie/${content.id}`}>
                    <Button variant="outline" className="gap-2">
                      <ArrowLeft className="w-4 h-4" />
                      معلومات الفيلم
                    </Button>
                  </Link>
                ) : (
                  <Link to={`/series/${content.id}`}>
                    <Button variant="outline" className="gap-2">
                      <ArrowLeft className="w-4 h-4" />
                      معلومات المسلسل
                    </Button>
                  </Link>
                )}
              </div>
            </div>

            {/* Sidebar */}
            <div className="md:w-80 space-y-6">
              {/* Ad Banner */}
              <AdBanner type="rectangle" />

              {/* Info Card */}
              <div className="bg-card rounded-xl p-6 border border-border">
                <h3 className="font-semibold text-foreground mb-4">معلومات</h3>
                <div className="space-y-3 text-sm">
                  {year && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">السنة:</span>
                      <span className="text-foreground">{year}</span>
                    </div>
                  )}

                  {'runtime' in content && content.runtime > 0 && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">المدة:</span>
                      <span className="text-foreground">{content.runtime} دقيقة</span>
                    </div>
                  )}

                  {'rating' in content && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">التقييم:</span>
                      <span className="text-foreground">{content.rating.toFixed(1)}</span>
                    </div>
                  )}

                  {episode && episode.runtime > 0 && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">مدة الحلقة:</span>
                      <span className="text-foreground">{episode.runtime} دقيقة</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
    </div>
        </div>
      </div>
    </div>
  );
}

  );
}
