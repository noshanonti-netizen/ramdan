import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useContent } from '@/context/ContentContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Film,
  Tv,
  TrendingUp,
  Users,
  ArrowRight,
  BarChart3,
  Calendar,
  Star,
} from 'lucide-react';
import localStorageService from '@/services/localStorage';
import type { Movie, Series } from '@/types';

export default function Dashboard() {
  const { movies, series } = useContent();
  const [stats, setStats] = useState({
    totalMovies: 0,
    totalSeries: 0,
    totalSeasons: 0,
    totalEpisodes: 0,
    featuredMovies: 0,
    featuredSeries: 0,
  });

  useEffect(() => {
    const loadStats = () => {
      const stats = localStorageService.getStatistics();
      setStats(stats);
    };

    loadStats();
  }, [movies, series]);

  // Get recent content
  const recentMovies = movies.slice(-5);
  const recentSeries = series.slice(-5);

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">لوحة التحكم</h1>
          <p className="text-muted-foreground mt-1">
            مرحباً بك في لوحة تحكم أفلاميكوز
          </p>
        </div>

        <div className="flex gap-2">
          <Link to="/admin/movies/add">
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              إضافة فيلم
            </Button>
          </Link>
          <Link to="/admin/series/add">
            <Button variant="outline" className="gap-2">
              <Plus className="w-4 h-4" />
              إضافة مسلسل
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي الأفلام</CardTitle>
            <Film className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalMovies}</div>
            <p className="text-xs text-muted-foreground">
              {stats.featuredMovies} مميز
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي المسلسلات</CardTitle>
            <Tv className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalSeries}</div>
            <p className="text-xs text-muted-foreground">
              {stats.featuredSeries} مميز
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي المواسم</CardTitle>
            <BarChart3 className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalSeasons}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي الحلقات</CardTitle>
            <Calendar className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalEpisodes}</div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Content */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Recent Movies */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Film className="w-5 h-5 text-primary" />
                أحدث الأفلام
              </CardTitle>
              <Link to="/admin/movies">
                <Button variant="ghost" size="sm" className="gap-1">
                  عرض الكل
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            {recentMovies.length > 0 ? (
              <div className="space-y-3">
                {recentMovies.map((movie) => (
                  <div
                    key={movie.id}
                    className="flex items-center gap-3 p-3 bg-secondary/50 rounded-lg hover:bg-secondary transition-colors"
                  >
                    <div className="w-12 h-16 bg-secondary rounded overflow-hidden flex-shrink-0">
                      <img
                        src={movie.posterPath}
                        alt={movie.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground truncate">
                        {movie.title}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {movie.releaseDate
                          ? new Date(movie.releaseDate).getFullYear()
                          : 'غير محدد'}
                      </p>
                    </div>
                    <div className="flex items-center gap-1 text-yellow-500">
                      <Star className="w-4 h-4 fill-yellow-500" />
                      <span className="text-sm font-medium">{movie.rating.toFixed(1)}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-8">
                لا توجد أفلام مضافة بعد
              </p>
            )}
          </CardContent>
        </Card>

        {/* Recent Series */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Tv className="w-5 h-5 text-primary" />
                أحدث المسلسلات
              </CardTitle>
              <Link to="/admin/series">
                <Button variant="ghost" size="sm" className="gap-1">
                  عرض الكل
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            {recentSeries.length > 0 ? (
              <div className="space-y-3">
                {recentSeries.map((series) => (
                  <div
                    key={series.id}
                    className="flex items-center gap-3 p-3 bg-secondary/50 rounded-lg hover:bg-secondary transition-colors"
                  >
                    <div className="w-12 h-16 bg-secondary rounded overflow-hidden flex-shrink-0">
                      <img
                        src={series.posterPath}
                        alt={series.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground truncate">
                        {series.name}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {series.firstAirDate
                          ? new Date(series.firstAirDate).getFullYear()
                          : 'غير محدد'}
                      </p>
                    </div>
                    <div className="flex items-center gap-1 text-yellow-500">
                      <Star className="w-4 h-4 fill-yellow-500" />
                      <span className="text-sm font-medium">{series.rating.toFixed(1)}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-8">
                لا توجد مسلسلات مضافة بعد
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>إجراءات سريعة</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Link to="/admin/movies/add">
              <Button variant="outline" className="w-full gap-2">
                <Plus className="w-4 h-4" />
                إضافة فيلم
              </Button>
            </Link>
            <Link to="/admin/series/add">
              <Button variant="outline" className="w-full gap-2">
                <Plus className="w-4 h-4" />
                إضافة مسلسل
              </Button>
            </Link>
            <Link to="/admin/settings">
              <Button variant="outline" className="w-full gap-2">
                <Settings className="w-4 h-4" />
                الإعدادات
              </Button>
            </Link>
            <Link to="/">
              <Button variant="outline" className="w-full gap-2">
                <TrendingUp className="w-4 h-4" />
                عرض الموقع
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
