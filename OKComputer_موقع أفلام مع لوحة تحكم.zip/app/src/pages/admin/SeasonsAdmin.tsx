import { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useContent } from '@/context/ContentContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  BarChart3,
  Plus,
  Trash2,
  Tv,
  Film,
} from 'lucide-react';
import type { Season, Series } from '@/types';
import localStorageService from '@/services/localStorage';

export default function SeasonsAdmin() {
  const { series: allSeries } = useContent();
  const [selectedSeries, setSelectedSeries] = useState('');
  const [seasons, setSeasons] = useState<Season[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (selectedSeries) {
      const seriesSeasons = localStorageService.getSeasonsBySeriesId(selectedSeries);
      setSeasons(seriesSeasons);
    } else {
      // Load all seasons
      const allSeasons: Season[] = [];
      allSeries.forEach((series) => {
        const seriesSeasons = localStorageService.getSeasonsBySeriesId(series.id);
        allSeasons.push(...seriesSeasons);
      });
      setSeasons(allSeasons);
    }
    setLoading(false);
  }, [selectedSeries, allSeries]);

  const handleDelete = (seasonId: string) => {
    if (confirm('هل أنت متأكد من حذف هذا الموسم؟')) {
      localStorageService.deleteSeason(seasonId);
      setSeasons(seasons.filter(s => s.id !== seasonId));
    }
  };

  // Get series name for a season
  const getSeriesName = (seriesId: string) => {
    const series = allSeries.find(s => s.id === seriesId);
    return series?.name || 'غير معروف';
  };

  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-3">
          <BarChart3 className="w-8 h-8 text-primary" />
          <div>
            <h1 className="text-2xl font-bold text-foreground">إدارة المواسم</h1>
            <p className="text-muted-foreground">
              {seasons.length} موسم
            </p>
          </div>
        </div>

        {/* Series Filter */}
        <Select value={selectedSeries} onValueChange={setSelectedSeries}>
          <SelectTrigger className="w-64">
            <SelectValue placeholder="اختر مسلسل" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">جميع المواسم</SelectItem>
            {allSeries.map((series) => (
              <SelectItem key={series.id} value={series.id}>
                {series.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Seasons Table */}
      <Card>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الملصق</TableHead>
                <TableHead>المسلسل</TableHead>
                <TableHead>الموسم</TableHead>
                <TableHead>الاسم</TableHead>
                <TableHead>الحلقات</TableHead>
                <TableHead>إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {seasons.length > 0 ? (
                seasons.map((season) => (
                  <TableRow key={season.id}>
                    <TableCell>
                      <div className="w-12 h-16 bg-secondary rounded overflow-hidden">
                        {season.posterPath ? (
                          <img
                            src={season.posterPath}
                            alt={season.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <Tv className="w-full h-full p-2 text-muted-foreground" />
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{getSeriesName(season.seriesId)}</TableCell>
                    <TableCell className="font-medium">
                      الموسم {season.seasonNumber}
                    </TableCell>
                    <TableCell>{season.name}</TableCell>
                    <TableCell>{season.episodeCount} حلقة</TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive"
                        onClick={() => handleDelete(season.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                    لا توجد مواسم
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
