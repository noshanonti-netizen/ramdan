import { useState, useEffect } from 'react';
import { Link, useNavigate, Routes, Route } from 'react-router-dom';
import { useContent } from '@/context/ContentContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Film,
  Plus,
  Edit,
  Trash2,
  Search,
  Star,
  Calendar,
  AlertCircle,
  CheckCircle,
  ExternalLink,
  X,
} from 'lucide-react';
import type { Movie } from '@/types';
import tmdbService from '@/services/tmdb';
import localStorageService from '@/services/localStorage';
import Loading from '@/components/Loading';

// Add/Edit Movie Component
function MovieForm() {
  const navigate = useNavigate();
  const { addMovie } = useContent();
  const [tmdbId, setTmdbId] = useState('');
  const [isFeatured, setIsFeatured] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!tmdbId.trim()) {
      setError('يرجى إدخال معرف TMDB');
      return;
    }

    setLoading(true);

    try {
      // Import from TMDB
      const importedMovie = await tmdbService.importMovieFromTMDB(
        parseInt(tmdbId),
        isFeatured
      );

      if (importedMovie) {
        addMovie(importedMovie);
        setSuccess('تم إضافة الفيلم بنجاح!');
        setTimeout(() => {
          navigate('/admin/movies');
        }, 2000);
      } else {
        setError('فشل في استيراد الفيلم من TMDB');
      }
    } catch (error: any) {
      setError(error.message || 'حدث خطأ أثناء إضافة الفيلم');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground mb-2">
          إضافة فيلم جديد
        </h1>
        <p className="text-muted-foreground">
          أدخل معرف TMDB للفيلم لاستيراده تلقائياً
        </p>
      </div>

      <Card className="max-w-2xl">
        <CardHeader>
          <CardTitle>معلومات الفيلم</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="flex items-center gap-2 text-destructive text-sm">
                <AlertCircle className="w-4 h-4" />
                <span>{error}</span>
              </div>
            )}

            {success && (
              <div className="flex items-center gap-2 text-green-500 text-sm">
                <CheckCircle className="w-4 h-4" />
                <span>{success}</span>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="tmdbId">
                معرف TMDB
                <a
                  href="https://www.themoviedb.org/movie"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline inline-flex items-center gap-1 mr-2"
                >
                  <ExternalLink className="w-3 h-3" />
                </a>
              </Label>
              <Input
                id="tmdbId"
                type="number"
                placeholder="مثال: 299534"
                value={tmdbId}
                onChange={(e) => setTmdbId(e.target.value)}
                required
              />
              <p className="text-xs text-muted-foreground">
                أدخل رقم معرف الفيلم من موقع TMDB
              </p>
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="isFeatured">فيلم مميز</Label>
              <Switch
                id="isFeatured"
                checked={isFeatured}
                onCheckedChange={setIsFeatured}
              />
            </div>

            <Button type="submit" disabled={loading} className="w-full">
              {loading ? 'جاري الاستيراد...' : 'استيراد من TMDB'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

// Movies List Component
function MoviesList() {
  const { movies, updateMovie, deleteMovie } = useContent();
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredMovies, setFilteredMovies] = useState<Movie[]>([]);
  const [deleteDialog, setDeleteDialog] = useState<Movie | null>(null);

  useEffect(() => {
    const filtered = movies.filter(
      (movie) =>
        movie.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        movie.genres.some((g) =>
          g.toLowerCase().includes(searchQuery.toLowerCase())
        )
    );
    setFilteredMovies(filtered);
  }, [searchQuery, movies]);

  const handleToggleFeatured = (movie: Movie) => {
    updateMovie(movie.id, { isFeatured: !movie.isFeatured });
  };

  const handleDelete = (movie: Movie) => {
    deleteMovie(movie.id);
    setDeleteDialog(null);
  };

  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-3">
          <Film className="w-8 h-8 text-primary" />
          <div>
            <h1 className="text-2xl font-bold text-foreground">إدارة الأفلام</h1>
            <p className="text-muted-foreground">
              {movies.length} فيلم
            </p>
          </div>
        </div>

        <Link to="/admin/movies/add">
          <Button className="gap-2">
            <Plus className="w-4 h-4" />
            إضافة فيلم
          </Button>
        </Link>
      </div>

      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <Input
          type="text"
          placeholder="بحث عن فيلم..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Movies Table */}
      <Card>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الملصق</TableHead>
                <TableHead>العنوان</TableHead>
                <TableHead>السنة</TableHead>
                <TableHead>التقييم</TableHead>
                <TableHead>التصنيفات</TableHead>
                <TableHead>مميز</TableHead>
                <TableHead>إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredMovies.length > 0 ? (
                filteredMovies.map((movie) => (
                  <TableRow key={movie.id}>
                    <TableCell>
                      <img
                        src={movie.posterPath}
                        alt={movie.title}
                        className="w-12 h-16 object-cover rounded"
                      />
                    </TableCell>
                    <TableCell className="font-medium">{movie.title}</TableCell>
                    <TableCell>
                      {movie.releaseDate
                        ? new Date(movie.releaseDate).getFullYear()
                        : '-'}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                        <span>{movie.rating.toFixed(1)}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {movie.genres.slice(0, 2).map((genre) => (
                          <span
                            key={genre}
                            className="text-xs bg-secondary px-2 py-1 rounded"
                          >
                            {genre}
                          </span>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Switch
                        checked={movie.isFeatured || false}
                        onCheckedChange={() => handleToggleFeatured(movie)}
                      />
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Link to={`/movie/${movie.id}`} target="_blank">
                          <Button variant="ghost" size="icon">
                            <ExternalLink className="w-4 h-4" />
                          </Button>
                        </Link>
                        <Dialog
                          open={deleteDialog?.id === movie.id}
                          onOpenChange={(open) =>
                            open ? setDeleteDialog(movie) : setDeleteDialog(null)
                          }
                        >
                          <DialogTrigger asChild>
                            <Button variant="ghost" size="icon" className="text-destructive">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>تأكيد الحذف</DialogTitle>
                            </DialogHeader>
                            <p className="text-muted-foreground">
                              هل أنت متأكد من حذف الفيلم "{movie.title}"؟
                            </p>
                            <div className="flex justify-end gap-2 mt-4">
                              <Button
                                variant="outline"
                                onClick={() => setDeleteDialog(null)}
                              >
                                إلغاء
                              </Button>
                              <Button
                                variant="destructive"
                                onClick={() => handleDelete(movie)}
                              >
                                حذف
                              </Button>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                    لا توجد أفلام
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

export default function MoviesAdmin() {
  return (
    <Routes>
      <Route path="/" element={<MoviesList />} />
      <Route path="/add" element={<MovieForm />} />
      <Route path="*" element={<MoviesList />} />
    </Routes>
  );
}
