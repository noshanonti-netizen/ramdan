import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useContent } from '@/context/ContentContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Film,
  Tv,
  Calendar,
  Clock,
  Trash2,
} from 'lucide-react';
import type { Episode, Season, Series } from '@/types';
import localStorageService from '@/services/localStorage';

export default function EpisodesAdmin() {
  const { series: allSeries } = useContent();
  const [selectedSeries, setSelectedSeries] = useState('');
  const [selectedSeason, setSelectedSeason] = useState('');
  const [seasons, setSeasons] = useState<Season[]>([]);
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [loading, setLoading] = useState(true);

  // Load seasons when series is selected
  useEffect(() => {
    if (selectedSeries) {
      const seriesSeasons = localStorageService.getSeasonsBySeriesId(selectedSeries);
      setSeasons(seriesSeasons);
      setSelectedSeason('');
      setEpisodes([]);
    } else {
      setSeasons([]);
      setSelectedSeason('');
      setEpisodes([]);
    }
  }, [selectedSeries]);

  // Load episodes when season is selected
  useEffect(() => {
    if (selectedSeason) {
      const seasonEpisodes = localStorageService.getEpisodesBySeasonId(selectedSeason);
      setEpisodes(seasonEpisodes);
    } else {
      setEpisodes([]);
    }
    setLoading(false);
  }, [selectedSeason]);

  const handleDelete = (episodeId: string) => {
    if (confirm('هل أنت متأكد من حذف هذه الحلقة؟')) {
      localStorageService.deleteEpisode(episodeId);
      setEpisodes(episodes.filter(e => e.id !== episodeId));
    }
  };

  // Get series name
  const getSeriesName = (seriesId: string) => {
    const series = allSeries.find(s => s.id === seriesId);
    return series?.name || 'غير معروف';
  };

  // Get season info
  const getSeasonInfo = (seasonId: string) => {
    const season = seasons.find(s => s.id === seasonId);
    return season;
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-4">
          <Film className="w-8 h-8 text-primary" />
          <h1 className="text-2xl font-bold text-foreground">إدارة الحلقات</h1>
        </div>
        <p className="text-muted-foreground">
          {episodes.length} حلقة
        </p>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <Select value={selectedSeries} onValueChange={setSelectedSeries}>
          <SelectTrigger className="w-full md:w-64">
            <SelectValue placeholder="اختر مسلسل" />
          </SelectTrigger>
          <SelectContent>
            {allSeries.map((series) => (
              <SelectItem key={series.id} value={series.id}>
                {series.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {seasons.length > 0 && (
          <Select value={selectedSeason} onValueChange={setSelectedSeason}>
            <SelectTrigger className="w-full md:w-64">
              <SelectValue placeholder="اختر موسم" />
            </SelectTrigger>
            <SelectContent>
              {seasons.map((season) => (
                <SelectItem key={season.id} value={season.id}>
                  الموسم {season.seasonNumber} - {season.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      {/* Episodes Table */}
      <Card>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الصورة</TableHead>
                <TableHead>الحلقة</TableHead>
                <TableHead>الاسم</TableHead>
                <TableHead>المسلسل</TableHead>
                <TableHead>الموسم</TableHead>
                <TableHead>التاريخ</TableHead>
                <TableHead>المدة</TableHead>
                <TableHead>إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {episodes.length > 0 ? (
                episodes.map((episode) => {
                  const season = getSeasonInfo(episode.seasonId);
                  return (
                    <TableRow key={episode.id}>
                      <TableCell>
                        <div className="w-16 h-10 bg-secondary rounded overflow-hidden">
                          {episode.stillPath ? (
                            <img
                              src={episode.stillPath}
                              alt={episode.name}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <Tv className="w-full h-full p-2 text-muted-foreground" />
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">
                        الحلقة {episode.episodeNumber}
                      </TableCell>
                      <TableCell>{episode.name}</TableCell>
                      <TableCell>
                        {season ? getSeriesName(season.seriesId) : '-'}
                      </TableCell>
                      <TableCell>
                        {season ? `الموسم ${season.seasonNumber}` : '-'}
                      </TableCell>
                      <TableCell>
                        {episode.airDate
                          ? new Date(episode.airDate).toLocaleDateString('ar')
                          : '-'}
                      </TableCell>
                      <TableCell>
                        {episode.runtime > 0 ? `${episode.runtime} د` : '-'}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-destructive"
                          onClick={() => handleDelete(episode.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })
              ) : (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                    {selectedSeason ? 'لا توجد حلقات في هذا الموسم' : 'اختر موسماً لعرض الحلقات'}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
