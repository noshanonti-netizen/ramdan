import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Settings,
  Trash2,
  Film,
  Tv,
} from 'lucide-react';
import type { Genre } from '@/types';
import localStorageService from '@/services/localStorage';

export default function CategoriesAdmin() {
  const [name, setName] = useState('');
  const [type, setType] = useState<'movie' | 'series' | 'both'>('both');
  const [genres, setGenres] = useState<Genre[]>(localStorageService.getGenres());

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) return;

    const newGenre: Genre = {
      id: `genre_${Date.now()}`,
      name: name.trim(),
      slug: name.trim().toLowerCase().replace(/\s+/g, '-'),
      type,
      createdAt: new Date().toISOString(),
    };

    localStorageService.addGenre(newGenre);
    setGenres(localStorageService.getGenres());
    setName('');
  };

  const handleDelete = (genreId: string) => {
    if (confirm('هل أنت متأكد من حذف هذا التصنيف؟')) {
      localStorageService.deleteGenre(genreId);
      setGenres(localStorageService.getGenres());
    }
  };

  const handleToggleType = (genre: Genre, newType: 'movie' | 'series' | 'both') => {
    localStorageService.updateGenre(genre.id, { type: newType });
    setGenres(localStorageService.getGenres());
  };

  return (
    <div className="p-6">
      <div className="flex items-center gap-3 mb-6">
        <Settings className="w-8 h-8 text-primary" />
        <h1 className="text-2xl font-bold text-foreground">إدارة التصنيفات</h1>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Add Category Form */}
        <Card>
          <CardHeader>
            <CardTitle>إضافة تصنيف جديد</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">اسم التصنيف</Label>
                <Input
                  id="name"
                  type="text"
                  placeholder="مثال: أكشن"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="type">النوع</Label>
                <Select value={type} onValueChange={(v) => setType(v as any)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="movie">أفلام فقط</SelectItem>
                    <SelectItem value="series">مسلسلات فقط</SelectItem>
                    <SelectItem value="both">كلاهما</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button type="submit" className="w-full">
                إضافة التصنيف
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Categories List */}
        <Card>
          <CardHeader>
            <CardTitle>التصنيفات ({genres.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>التصنيف</TableHead>
                  <TableHead>النوع</TableHead>
                  <TableHead>إجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {genres.length > 0 ? (
                  genres.map((genre) => (
                    <TableRow key={genre.id}>
                      <TableCell className="font-medium">{genre.name}</TableCell>
                      <TableCell>
                        <Select
                          value={genre.type}
                          onValueChange={(v) => handleToggleType(genre, v as any)}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="movie">أفلام</SelectItem>
                            <SelectItem value="series">مسلسلات</SelectItem>
                            <SelectItem value="both">كلاهما</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-destructive"
                          onClick={() => handleDelete(genre.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center py-8 text-muted-foreground">
                      لا توجد تصنيفات
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
