import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import {
  Settings,
  Save,
  CheckCircle,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';
import type { AppSettings } from '@/types';
import localStorageService from '@/services/localStorage';
import tmdbService from '@/services/tmdb';

export default function SettingsAdmin() {
  const [settings, setSettings] = useState<AppSettings>({
    tmdbApiKey: '',
    siteName: 'أفلاميكوز',
    siteDescription: '',
    siteKeywords: [],
    enableAds: false,
    clickaduCode: '',
    primaryColor: '#dc2626',
    enableRegistration: true,
  });
  const [keywordsInput, setKeywordsInput] = useState('');
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState('');

  useEffect(() => {
    const loadSettings = () => {
      const savedSettings = localStorageService.getSettings();
      setSettings(savedSettings);
      setKeywordsInput(savedSettings.siteKeywords.join(', '));
    };

    loadSettings();
  }, []);

  const testApiKey = async () => {
    if (!settings.tmdbApiKey.trim()) {
      setTestResult({ success: false, message: 'يرجى إدخال مفتاح API' });
      return;
    }

    setIsTesting(true);
    setTestResult(null);

    try {
      tmdbService.setApiKey(settings.tmdbApiKey);
      await tmdbService.getConfiguration();
      setTestResult({ success: true, message: 'تم التحقق من المفتاح بنجاح!' });
    } catch (error: any) {
      setTestResult({ 
        success: false, 
        message: error.message || 'فشل التحقق من المفتاح'
      });
    } finally {
      setIsTesting(false);
    }
  };

  const saveSettings = async () => {
    setIsSaving(true);
    
    try {
      const updatedSettings: AppSettings = {
        ...settings,
        siteKeywords: keywordsInput.split(',').map(k => k.trim()).filter(k => k),
      };

      localStorageService.saveSettings(updatedSettings);
      
      // Update TMDB service with new API key
      if (updatedSettings.tmdbApiKey) {
        tmdbService.setApiKey(updatedSettings.tmdbApiKey);
      }

      setSaveMessage('تم حفظ الإعدادات بنجاح!');
      setTimeout(() => setSaveMessage(''), 3000);
    } catch (error) {
      setSaveMessage('حدث خطأ أثناء الحفظ');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="p-6">
      <div className="flex items-center gap-3 mb-6">
        <Settings className="w-8 h-8 text-primary" />
        <h1 className="text-2xl font-bold text-foreground">إعدادات الموقع</h1>
      </div>

      <div className="space-y-6">
        {/* TMDB API Key */}
        <Card>
          <CardHeader>
            <CardTitle>مفتاح TMDB API</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="tmdbApiKey">
                مفتاح API
                <a
                  href="https://www.themoviedb.org/settings/api"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline inline-flex items-center gap-1 mr-2"
                >
                  <ExternalLink className="w-3 h-3" />
                </a>
              </Label>
              <Input
                id="tmdbApiKey"
                type="text"
                placeholder="أدخل مفتاح API الخاص بك"
                value={settings.tmdbApiKey}
                onChange={(e) => setSettings({ ...settings, tmdbApiKey: e.target.value })}
              />
            </div>
            
            <div className="flex gap-3">
              <Button 
                onClick={testApiKey}
                disabled={isTesting}
                variant="outline"
              >
                {isTesting ? 'جاري التحقق...' : 'اختبار المفتاح'}
              </Button>
            </div>

            {testResult && (
              <div className={`flex items-center gap-2 text-sm ${
                testResult.success ? 'text-green-500' : 'text-destructive'
              }`}>
                {testResult.success ? (
                  <CheckCircle className="w-4 h-4" />
                ) : (
                  <AlertCircle className="w-4 h-4" />
                )}
                <span>{testResult.message}</span>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Site Settings */}
        <Card>
          <CardHeader>
            <CardTitle>إعدادات الموقع</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="siteName">اسم الموقع</Label>
              <Input
                id="siteName"
                type="text"
                value={settings.siteName}
                onChange={(e) => setSettings({ ...settings, siteName: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="siteDescription">وصف الموقع</Label>
              <Textarea
                id="siteDescription"
                value={settings.siteDescription}
                onChange={(e) => setSettings({ ...settings, siteDescription: e.target.value })}
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="siteKeywords">الكلمات الدلالية (مفصولة بفاصلة)</Label>
              <Input
                id="siteKeywords"
                type="text"
                value={keywordsInput}
                onChange={(e) => setKeywordsInput(e.target.value)}
                placeholder="أفلام, مسلسلات, مشاهدة, اون لاين"
              />
            </div>
          </CardContent>
        </Card>

        {/* Ads Settings */}
        <Card>
          <CardHeader>
            <CardTitle>إعدادات الإعلانات</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="enableAds">تفعيل الإعلانات</Label>
              <Switch
                id="enableAds"
                checked={settings.enableAds}
                onCheckedChange={(checked) => setSettings({ ...settings, enableAds: checked })}
              />
            </div>

            {settings.enableAds && (
              <div className="space-y-2">
                <Label htmlFor="clickaduCode">كود Clickadu</Label>
                <Textarea
                  id="clickaduCode"
                  value={settings.clickaduCode}
                  onChange={(e) => setSettings({ ...settings, clickaduCode: e.target.value })}
                  placeholder="أدخل كود الإعلانات هنا..."
                  rows={4}
                />
                <p className="text-xs text-muted-foreground">
                  احصل على كود الإعلانات من{' '}
                  <a 
                    href="https://www.clickadu.com" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-primary hover:underline"
                  >
                    clickadu.com
                  </a>
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Save Button */}
        <div className="flex justify-end">
          <Button 
            onClick={saveSettings}
            disabled={isSaving}
            className="gap-2"
          >
            {isSaving ? (
              <>
                <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                جاري الحفظ...
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                حفظ الإعدادات
              </>
            )}
          </Button>
        </div>

        {saveMessage && (
          <div className={`flex items-center gap-2 text-sm ${
            saveMessage.includes('خطأ') ? 'text-destructive' : 'text-green-500'
          }`}>
            {saveMessage.includes('خطأ') ? (
              <AlertCircle className="w-4 h-4" />
            ) : (
              <CheckCircle className="w-4 h-4" />
            )}
            <span>{saveMessage}</span>
          </div>
        )}
      </div>
    </div>
  );
}
