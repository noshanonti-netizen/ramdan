import { useState, useEffect } from 'react';
import { Link, Routes, Route, useNavigate } from 'react-router-dom';
import { useContent } from '@/context/ContentContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Tv,
  Plus,
  Edit,
  Trash2,
  Search,
  Star,
  Calendar,
  ExternalLink,
  X,
} from 'lucide-react';
import type { Series } from '@/types';
import tmdbService from '@/services/tmdb';
import localStorageService from '@/services/localStorage';

// Add Series Component
function SeriesForm() {
  const navigate = useNavigate();
  const { addSeries } = useContent();
  const [tmdbId, setTmdbId] = useState('');
  const [isFeatured, setIsFeatured] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!tmdbId.trim()) {
      setError('يرجى إدخال معرف TMDB');
      return;
    }

    setLoading(true);

    try {
      const importedSeries = await tmdbService.importSeriesFromTMDB(
        parseInt(tmdbId),
        isFeatured
      );

      if (importedSeries) {
        addSeries(importedSeries);
        setSuccess('تم إضافة المسلسل بنجاح!');
        setTimeout(() => {
          navigate('/admin/series');
        }, 2000);
      } else {
        setError('فشل في استيراد المسلسل من TMDB');
      }
    } catch (error: any) {
      setError(error.message || 'حدث خطأ أثناء إضافة المسلسل');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground mb-2">
          إضافة مسلسل جديد
        </h1>
        <p className="text-muted-foreground">
          أدخل معرف TMDB للمسلسل لاستيراده تلقائياً
        </p>
      </div>

      <Card className="max-w-2xl">
        <CardHeader>
          <CardTitle>معلومات المسلسل</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="flex items-center gap-2 text-destructive text-sm">
                <AlertCircle className="w-4 h-4" />
                <span>{error}</span>
              </div>
            )}

            {success && (
              <div className="flex items-center gap-2 text-green-500 text-sm">
                <CheckCircle className="w-4 h-4" />
                <span>{success}</span>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="tmdbId">
                معرف TMDB
                <a
                  href="https://www.themoviedb.org/tv"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline inline-flex items-center gap-1 mr-2"
                >
                  <ExternalLink className="w-3 h-3" />
                </a>
              </Label>
              <Input
                id="tmdbId"
                type="number"
                placeholder="مثال: 1399"
                value={tmdbId}
                onChange={(e) => setTmdbId(e.target.value)}
                required
              />
              <p className="text-xs text-muted-foreground">
                أدخل رقم معرف المسلسل من موقع TMDB
              </p>
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="isFeatured">مسلسل مميز</Label>
              <Switch
                id="isFeatured"
                checked={isFeatured}
                onCheckedChange={setIsFeatured}
              />
            </div>

            <Button type="submit" disabled={loading} className="w-full">
              {loading ? 'جاري الاستيراد...' : 'استيراد من TMDB'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

// Series List Component
function SeriesList() {
  const { series: allSeries, updateSeries, deleteSeries } = useContent();
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredSeries, setFilteredSeries] = useState<Series[]>([]);
  const [deleteDialog, setDeleteDialog] = useState<Series | null>(null);

  useEffect(() => {
    const filtered = allSeries.filter(
      (s) =>
        s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.genres.some((g) =>
          g.toLowerCase().includes(searchQuery.toLowerCase())
        )
    );
    setFilteredSeries(filtered);
  }, [searchQuery, allSeries]);

  const handleToggleFeatured = (series: Series) => {
    updateSeries(series.id, { isFeatured: !series.isFeatured });
  };

  const handleDelete = (series: Series) => {
    deleteSeries(series.id);
    setDeleteDialog(null);
  };

  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-3">
          <Tv className="w-8 h-8 text-primary" />
          <div>
            <h1 className="text-2xl font-bold text-foreground">إدارة المسلسلات</h1>
            <p className="text-muted-foreground">
              {allSeries.length} مسلسل
            </p>
          </div>
        </div>

        <Link to="/admin/series/add">
          <Button className="gap-2">
            <Plus className="w-4 h-4" />
            إضافة مسلسل
          </Button>
        </Link>
      </div>

      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <Input
          type="text"
          placeholder="بحث عن مسلسل..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Series Table */}
      <Card>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الملصق</TableHead>
                <TableHead>العنوان</TableHead>
                <TableHead>السنة</TableHead>
                <TableHead>التقييم</TableHead>
                <TableHead>المواسم</TableHead>
                <TableHead>مميز</TableHead>
                <TableHead>إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredSeries.length > 0 ? (
                filteredSeries.map((series) => (
                  <TableRow key={series.id}>
                    <TableCell>
                      <img
                        src={series.posterPath}
                        alt={series.name}
                        className="w-12 h-16 object-cover rounded"
                      />
                    </TableCell>
                    <TableCell className="font-medium">{series.name}</TableCell>
                    <TableCell>
                      {series.firstAirDate
                        ? new Date(series.firstAirDate).getFullYear()
                        : '-'}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                        <span>{series.rating.toFixed(1)}</span>
                      </div>
                    </TableCell>
                    <TableCell>{series.numberOfSeasons}</TableCell>
                    <TableCell>
                      <Switch
                        checked={series.isFeatured || false}
                        onCheckedChange={() => handleToggleFeatured(series)}
                      />
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Link to={`/series/${series.id}`} target="_blank">
                          <Button variant="ghost" size="icon">
                            <ExternalLink className="w-4 h-4" />
                          </Button>
                        </Link>
                        <Dialog
                          open={deleteDialog?.id === series.id}
                          onOpenChange={(open) =>
                            open ? setDeleteDialog(series) : setDeleteDialog(null)
                          }
                        >
                          <DialogTrigger asChild>
                            <Button variant="ghost" size="icon" className="text-destructive">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>تأكيد الحذف</DialogTitle>
                            </DialogHeader>
                            <p className="text-muted-foreground">
                              هل أنت متأكد من حذف المسلسل "{series.name}"؟
                            </p>
                            <div className="flex justify-end gap-2 mt-4">
                              <Button
                                variant="outline"
                                onClick={() => setDeleteDialog(null)}
                              >
                                إلغاء
                              </Button>
                              <Button
                                variant="destructive"
                                onClick={() => handleDelete(series)}
                              >
                                حذف
                              </Button>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                    لا توجد مسلسلات
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

export default function SeriesAdmin() {
  return (
    <Routes>
      <Route path="/" element={<SeriesList />} />
      <Route path="/add" element={<SeriesForm />} />
      <Route path="*" element={<SeriesList />} />
    </Routes>
  );
}
