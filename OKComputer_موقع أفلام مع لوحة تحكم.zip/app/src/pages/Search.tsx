import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useContent } from '@/context/ContentContext';
import SEO from '@/components/SEO';
import AdBanner from '@/components/AdBanner';
import Loading from '@/components/Loading';
import MovieCard from '@/components/MovieCard';
import SeriesCard from '@/components/SeriesCard';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Film, Tv, X } from 'lucide-react';
import type { Movie, Series } from '@/types';

export default function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { searchContent } = useContent();
  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '');
  const [activeTab, setActiveTab] = useState<'all' | 'movies' | 'series'>('all');
  const [searchResults, setSearchResults] = useState<(Movie | Series)[]>([]);
  const [loading, setLoading] = useState(false);

  // Perform search
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }

    setLoading(true);
    const filters = {
      query: searchQuery,
      type: activeTab === 'all' ? 'all' as const : activeTab === 'movies' ? 'movie' as const : 'series' as const,
      genres: [],
      year: '',
      sortBy: 'rating' as const,
      page: 1,
    };

    const results = searchContent(filters);
    setSearchResults(results);
    setLoading(false);
  }, [searchQuery, activeTab, searchContent]);

  // Update URL params
  useEffect(() => {
    const params = new URLSearchParams();
    if (searchQuery) params.set('q', searchQuery);
    if (activeTab !== 'all') params.set('type', activeTab);
    setSearchParams(params, { replace: true });
  }, [searchQuery, activeTab, setSearchParams]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Search is already performed on query change
  };

  const clearSearch = () => {
    setSearchQuery('');
    setSearchResults([]);
  };

  // Filter results by type
  const movieResults = searchResults.filter(r => 'title' in r) as Movie[];
  const seriesResults = searchResults.filter(r => 'name' in r) as Series[];

  return (
    <div className="min-h-screen py-8 px-4">
      <SEO 
        title={searchQuery ? `بحث: ${searchQuery}` : "بحث"}
        description="ابحث عن أفلام ومسلسلات في أفلاميكوز"
        type="website"
      />

      <div className="max-w-7xl mx-auto">
        {/* Search Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-6 flex items-center justify-center gap-3">
            <Search className="w-8 h-8 text-primary" />
            بحث
          </h1>

          {/* Search Form */}
          <form onSubmit={handleSearch} className="max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="ابحث عن فيلم أو مسلسل..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 pr-12 py-6 text-lg"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={clearSearch}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="w-5 h-5" />
                </button>
              )}
            </div>
          </form>
        </div>

        {/* Ad Banner */}
        <div className="mb-8">
          <AdBanner type="leaderboard" />
        </div>

        {/* Results */}
        {searchQuery ? (
          <>
            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)} className="mb-8">
              <TabsList className="grid w-full max-w-md mx-auto grid-cols-3">
                <TabsTrigger value="all">
                  الكل ({searchResults.length})
                </TabsTrigger>
                <TabsTrigger value="movies">
                  <Film className="w-4 h-4 mr-2" />
                  أفلام ({movieResults.length})
                </TabsTrigger>
                <TabsTrigger value="series">
                  <Tv className="w-4 h-4 mr-2" />
                  مسلسلات ({seriesResults.length})
                </TabsTrigger>
              </TabsList>

              <TabsContent value="all" className="mt-6">
                {loading ? (
                  <Loading message="جاري البحث..." />
                ) : searchResults.length > 0 ? (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                    {searchResults.map((item) =>
                      'title' in item ? (
                        <MovieCard key={item.id} movie={item} />
                      ) : (
                        <SeriesCard key={item.id} series={item} />
                      )
                    )}
                  </div>
                ) : (
                  <div className="text-center py-16">
                    <Search className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-foreground mb-2">
                      لا توجد نتائج
                    </h3>
                    <p className="text-muted-foreground">
                      لم يتم العثور على نتائج لـ "{searchQuery}"
                    </p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="movies" className="mt-6">
                {loading ? (
                  <Loading message="جاري البحث..." />
                ) : movieResults.length > 0 ? (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                    {movieResults.map((movie) => (
                      <MovieCard key={movie.id} movie={movie} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-16">
                    <Film className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-foreground mb-2">
                      لا توجد أفلام
                    </h3>
                    <p className="text-muted-foreground">
                      لم يتم العثور على أفلام لـ "{searchQuery}"
                    </p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="series" className="mt-6">
                {loading ? (
                  <Loading message="جاري البحث..." />
                ) : seriesResults.length > 0 ? (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                    {seriesResults.map((series) => (
                      <SeriesCard key={series.id} series={series} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-16">
                    <Tv className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-foreground mb-2">
                      لا توجد مسلسلات
                    </h3>
                    <p className="text-muted-foreground">
                      لم يتم العثور على مسلسلات لـ "{searchQuery}"
                    </p>
                  </div>
                )}
              </TabsContent>
            </Tabs>

            {/* Ad Banner */}
            <div className="mt-8">
              <AdBanner type="leaderboard" />
            </div>
          </>
        ) : (
          /* Popular Searches / Suggestions */
          <div className="text-center py-16">
            <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <Search className="w-10 h-10 text-primary" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-4">
              ماذا تريد أن تشاهد؟
            </h3>
            <p className="text-muted-foreground mb-8 max-w-md mx-auto">
              ابدأ بالبحث عن أفلامك ومسلسلاتك المفضلة. يمكنك البحث بالاسم، التصنيف، أو السنة.
            </p>

            {/* Quick Suggestions */}
            <div className="flex flex-wrap justify-center gap-2">
              {['أكشن', 'دراما', 'كوميدي', '2023', '2024', 'رعب'].map((suggestion) => (
                <Button
                  key={suggestion}
                  variant="outline"
                  onClick={() => setSearchQuery(suggestion)}
                >
                  {suggestion}
                </Button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}