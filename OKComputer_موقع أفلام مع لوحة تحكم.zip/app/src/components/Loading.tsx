import { Film, Loader2 } from 'lucide-react';

interface LoadingProps {
  message?: string;
  size?: 'sm' | 'md' | 'lg';
  fullScreen?: boolean;
}

export default function Loading({ 
  message = 'جاري التحميل...', 
  size = 'md',
  fullScreen = false 
}: LoadingProps) {
  const sizeClasses = {
    sm: 'w-6 h-6',
    md: 'w-10 h-10',
    lg: 'w-16 h-16',
  };

  const containerClasses = fullScreen
    ? 'fixed inset-0 bg-background/95 backdrop-blur-sm flex items-center justify-center z-50'
    : 'flex flex-col items-center justify-center py-12';

  return (
    <div className={containerClasses}>
      <div className="flex flex-col items-center gap-4">
        {/* Logo Animation */}
        <div className="relative">
          <div className="w-20 h-20 bg-primary/10 rounded-2xl flex items-center justify-center animate-pulse">
            <Film className="w-10 h-10 text-primary" />
          </div>
          <div className="absolute -bottom-2 left-1/2 -translate-x-1/2">
            <Loader2 className={`${sizeClasses[size]} text-primary animate-spin`} />
          </div>
        </div>

        {/* Message */}
        <div className="text-center">
          <p className="text-foreground font-medium">{message}</p>
          <p className="text-muted-foreground text-sm mt-1">يرجى الانتظار قليلاً...</p>
        </div>

        {/* Loading Dots */}
        <div className="flex gap-1 mt-2">
          <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
          <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
          <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
        </div>
      </div>
    </div>
  );
}

// Skeleton loading component for cards
export function ContentCardSkeleton() {
  return (
    <div className="content-card animate-pulse">
      <div className="aspect-[2/3] bg-secondary rounded-t-xl" />
      <div className="p-4">
        <div className="h-4 bg-secondary rounded w-3/4 mb-2" />
        <div className="h-3 bg-secondary rounded w-1/2" />
      </div>
    </div>
  );
}

// Skeleton loading for hero section
export function HeroSkeleton() {
  return (
    <div className="relative h-[70vh] min-h-[500px] w-full animate-pulse">
      <div className="absolute inset-0 bg-secondary" />
      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 p-8">
        <div className="max-w-4xl">
          <div className="h-8 bg-secondary rounded w-3/4 mb-4" />
          <div className="h-4 bg-secondary rounded w-full mb-2" />
          <div className="h-4 bg-secondary rounded w-5/6 mb-6" />
          <div className="flex gap-3">
            <div className="h-10 w-32 bg-primary/30 rounded" />
            <div className="h-10 w-32 bg-secondary rounded" />
          </div>
        </div>
      </div>
    </div>
  );
}
