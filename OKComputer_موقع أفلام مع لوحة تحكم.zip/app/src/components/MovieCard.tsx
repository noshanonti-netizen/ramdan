import { Link } from 'react-router-dom';
import { Star, Play, Calendar } from 'lucide-react';
import type { Movie } from '@/types';
import tmdbService from '@/services/tmdb';
import { Badge } from '@/components/ui/badge';

interface MovieCardProps {
  movie: Movie;
  showYear?: boolean;
  showRating?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export default function MovieCard({ 
  movie, 
  showYear = true, 
  showRating = true,
  size = 'md' 
}: MovieCardProps) {
  const imageUrl = tmdbService.getImageUrl(movie.posterPath, size === 'lg' ? 'w500' : size === 'sm' ? 'w185' : 'w342');
  const year = movie.releaseDate ? new Date(movie.releaseDate).getFullYear() : '';

  const sizeClasses = {
    sm: 'w-32',
    md: 'w-44',
    lg: 'w-64',
  };

  return (
    <Link to={`/movie/${movie.id}`} className="movie-card block group">
      <div className={`${sizeClasses[size]} relative overflow-hidden rounded-xl bg-secondary`}>
        {/* Image */}
        <div className="aspect-[2/3] relative overflow-hidden">
          <img
            src={imageUrl}
            alt={movie.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            loading="lazy"
          />
          
          {/* Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          {/* Play Button */}
          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="w-14 h-14 bg-primary/90 rounded-full flex items-center justify-center transform scale-75 group-hover:scale-100 transition-transform">
              <Play className="w-6 h-6 text-primary-foreground ml-1" />
            </div>
          </div>

          {/* Featured Badge */}
          {movie.isFeatured && (
            <Badge className="absolute top-2 left-2 bg-primary text-primary-foreground border-0">
              مميز
            </Badge>
          )}

          {/* Rating Badge */}
          {showRating && (
            <div className="absolute top-2 right-2 bg-background/80 backdrop-blur-sm rounded-lg px-2 py-1 flex items-center gap-1">
              <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
              <span className="text-xs font-medium">{movie.rating.toFixed(1)}</span>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-3">
          {/* Title */}
          <h3 className="text-foreground font-medium text-sm line-clamp-1 mb-1 group-hover:text-primary transition-colors">
            {movie.title}
          </h3>

          {/* Meta */}
          <div className="flex items-center justify-between">
            {showYear && year && (
              <div className="flex items-center gap-1 text-muted-foreground text-xs">
                <Calendar className="w-3 h-3" />
                <span>{year}</span>
              </div>
            )}
            
            {/* Genres */}
            {movie.genres.length > 0 && (
              <div className="flex gap-1 flex-wrap">
                {movie.genres.slice(0, 1).map((genre) => (
                  <span
                    key={genre}
                    className="text-xs text-muted-foreground"
                  >
                    {genre}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
}
