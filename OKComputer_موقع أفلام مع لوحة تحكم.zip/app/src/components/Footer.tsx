import { Link } from 'react-router-dom';
import { Film, Facebook, Twitter, Instagram, Youtube, Mail, Phone, MapPin } from 'lucide-react';
import localStorageService from '@/services/localStorage';
import { useEffect, useState } from 'react';
import type { AppSettings } from '@/types';

export default function Footer() {
  const [settings, setSettings] = useState<AppSettings | null>(null);

  useEffect(() => {
    const loadedSettings = localStorageService.getSettings();
    setSettings(loadedSettings);
  }, []);

  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-card border-t border-border mt-16">
      {/* Clickadu Ad Banner */}
      <div className="py-4 border-b border-border">
        <div className="max-w-7xl mx-auto px-4">
          <div className="ad-banner-large">
            <span className="text-muted-foreground text-sm">مساحة إعلانية - Clickadu</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="lg:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Film className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold text-foreground">
                أفلامي<span className="text-primary">كوز</span>
              </span>
            </Link>
            <p className="text-muted-foreground text-sm leading-relaxed mb-6">
              {settings?.siteDescription || 'أفضل موقع لمشاهدة الأفلام والمسلسلات العربية والأجنبية المترجمة بجودة عالية.'}
            </p>
            {/* Social Links */}
            <div className="flex gap-3">
              <a
                href="#"
                className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center text-foreground/70 hover:bg-primary hover:text-primary-foreground transition-all"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center text-foreground/70 hover:bg-primary hover:text-primary-foreground transition-all"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center text-foreground/70 hover:bg-primary hover:text-primary-foreground transition-all"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center text-foreground/70 hover:bg-primary hover:text-primary-foreground transition-all"
              >
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-4">روابط سريعة</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/" className="text-muted-foreground hover:text-primary transition-colors">
                  الرئيسية
                </Link>
              </li>
              <li>
                <Link to="/movies" className="text-muted-foreground hover:text-primary transition-colors">
                  الأفلام
                </Link>
              </li>
              <li>
                <Link to="/series" className="text-muted-foreground hover:text-primary transition-colors">
                  المسلسلات
                </Link>
              </li>
              <li>
                <Link to="/search" className="text-muted-foreground hover:text-primary transition-colors">
                  بحث
                </Link>
              </li>
              <li>
                <Link to="/admin" className="text-muted-foreground hover:text-primary transition-colors">
                  لوحة التحكم
                </Link>
              </li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-4">التصنيفات</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/movies?genre=action" className="text-muted-foreground hover:text-primary transition-colors">
                  أفلام أكشن
                </Link>
              </li>
              <li>
                <Link to="/movies?genre=drama" className="text-muted-foreground hover:text-primary transition-colors">
                  أفلام دراما
                </Link>
              </li>
              <li>
                <Link to="/movies?genre=comedy" className="text-muted-foreground hover:text-primary transition-colors">
                  أفلام كوميدي
                </Link>
              </li>
              <li>
                <Link to="/series?genre=action" className="text-muted-foreground hover:text-primary transition-colors">
                  مسلسلات أكشن
                </Link>
              </li>
              <li>
                <Link to="/series?genre=drama" className="text-muted-foreground hover:text-primary transition-colors">
                  مسلسلات دراما
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-4">تواصل معنا</h3>
            <ul className="space-y-4">
              <li className="flex items-center gap-3 text-muted-foreground">
                <Mail className="w-5 h-5 text-primary" />
                <span>contact@aflamix.com</span>
              </li>
              <li className="flex items-center gap-3 text-muted-foreground">
                <Phone className="w-5 h-5 text-primary" />
                <span>+123 456 7890</span>
              </li>
              <li className="flex items-center gap-3 text-muted-foreground">
                <MapPin className="w-5 h-5 text-primary" />
                <span>القاهرة، مصر</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-border flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-muted-foreground text-sm">
            © {currentYear} {settings?.siteName || 'أفلاميكوز'}. جميع الحقوق محفوظة.
          </p>
          <div className="flex gap-6 text-sm">
            <Link to="/privacy" className="text-muted-foreground hover:text-primary transition-colors">
              سياسة الخصوصية
            </Link>
            <Link to="/terms" className="text-muted-foreground hover:text-primary transition-colors">
              terms of use
            </Link>
            <Link to="/dmca" className="text-muted-foreground hover:text-primary transition-colors">
              DMCA
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
