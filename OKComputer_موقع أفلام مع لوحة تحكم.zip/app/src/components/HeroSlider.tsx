import { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Play, Star, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { Movie, Series } from '@/types';
import tmdbService from '@/services/tmdb';
import Loading from '@/components/Loading';

interface HeroSliderProps {
  items: (Movie | Series)[];
  loading?: boolean;
}

export default function HeroSlider({ items, loading }: HeroSliderProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const goToSlide = useCallback((index: number) => {
    setCurrentSlide(index);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 5000);
  }, []);

  const nextSlide = useCallback(() => {
    setCurrentSlide((prev) => (prev + 1) % items.length);
  }, [items.length]);

  const prevSlide = useCallback(() => {
    setCurrentSlide((prev) => (prev - 1 + items.length) % items.length);
  }, [items.length]);

  // Auto-play
  useEffect(() => {
    if (!isAutoPlaying || items.length === 0) return;

    const interval = setInterval(() => {
      nextSlide();
    }, 6000);

    return () => clearInterval(interval);
  }, [isAutoPlaying, nextSlide, items.length]);

  if (loading) {
    return <Loading fullScreen message="جاري تحميل المحتوى المميز..." />;
  }

  if (items.length === 0) {
    return null;
  }

  return (
    <div className="relative h-[70vh] min-h-[500px] max-h-[800px] w-full overflow-hidden">
      {/* Slides */}
      <div className="relative h-full">
        {items.map((item, index) => {
          const itemIsMovie = 'title' in item;
          const itemTitle = itemIsMovie ? item.title : item.name;
          const itemDate = itemIsMovie ? item.releaseDate : item.firstAirDate;
          const itemYear = itemDate ? new Date(itemDate).getFullYear() : '';
          const itemImageUrl = item.backdropPath
            ? tmdbService.getBackdropUrl(item.backdropPath, 'w1280')
            : tmdbService.getImageUrl(item.posterPath, 'w1280');

          return (
            <div
              key={item.id}
              className={`absolute inset-0 transition-all duration-700 ease-out ${
                index === currentSlide
                  ? 'opacity-100 scale-100'
                  : 'opacity-0 scale-105'
              }`}
            >
              {/* Background Image */}
              <div
                className="absolute inset-0 bg-cover bg-center"
                style={{ backgroundImage: `url(${itemImageUrl})` }}
              />
              
              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-r from-background/80 via-transparent to-transparent" />

              {/* Content */}
              <div className="absolute bottom-0 left-0 right-0 p-6 md:p-12 lg:p-16">
                <div className="max-w-4xl">
                  {/* Year and Rating */}
                  <div className="flex items-center gap-4 mb-4">
                    {itemYear && (
                      <div className="flex items-center gap-1 text-foreground/80">
                        <Calendar className="w-4 h-4" />
                        <span className="text-sm font-medium">{itemYear}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                      <span className="text-sm font-medium text-foreground/80">
                        {item.rating.toFixed(1)}
                      </span>
                    </div>
                    <div className="flex gap-2">
                      {item.genres.slice(0, 3).map((genre) => (
                        <span
                          key={genre}
                          className="badge-genre"
                        >
                          {genre}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Title */}
                  <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold text-foreground mb-4 leading-tight">
                    {itemTitle}
                  </h1>

                  {/* Overview */}
                  <p className="text-foreground/80 text-base md:text-lg max-w-2xl mb-6 line-clamp-3">
                    {item.overview}
                  </p>

                  {/* Buttons */}
                  <div className="flex flex-wrap gap-3">
                    <Link
                      to={itemIsMovie ? `/movie/${item.id}` : `/series/${item.id}`}
                    >
                      <Button
                        size="lg"
                        className="gap-2 bg-primary hover:bg-primary/90 text-primary-foreground"
                      >
                        <Play className="w-5 h-5" />
                        مشاهدة الآن
                      </Button>
                    </Link>
                    <Link
                      to={itemIsMovie ? `/movie/${item.id}` : `/series/${item.id}`}
                    >
                      <Button
                        size="lg"
                        variant="outline"
                        className="border-2 border-foreground/20 text-foreground hover:bg-foreground/10"
                      >
                        معلومات أكثر
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Navigation Arrows */}
      <button
        onClick={prevSlide}
        className="absolute left-4 md:left-8 top-1/2 -translate-y-1/2 w-12 h-12 bg-background/50 hover:bg-background/80 backdrop-blur-sm rounded-full flex items-center justify-center text-foreground transition-all z-10"
      >
        <ChevronRight className="w-6 h-6" />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2 w-12 h-12 bg-background/50 hover:bg-background/80 backdrop-blur-sm rounded-full flex items-center justify-center text-foreground transition-all z-10"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>

      {/* Slide Indicators */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2 z-10">
        {items.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`transition-all duration-300 ${
              index === currentSlide
                ? 'w-8 h-2 bg-primary rounded-full'
                : 'w-2 h-2 bg-foreground/30 hover:bg-foreground/50 rounded-full'
            }`}
          />
        ))}
      </div>
    </div>
  );
}
