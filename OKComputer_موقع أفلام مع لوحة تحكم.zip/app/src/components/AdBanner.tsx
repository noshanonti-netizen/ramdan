import { useEffect, useState } from 'react';
import localStorageService from '@/services/localStorage';
import type { AppSettings } from '@/types';

interface AdBannerProps {
  type?: 'banner' | 'rectangle' | 'skyscraper' | 'leaderboard';
  className?: string;
}

export default function AdBanner({ type = 'banner', className = '' }: AdBannerProps) {
  const [settings, setSettings] = useState<AppSettings | null>(null);

  useEffect(() => {
    const loadedSettings = localStorageService.getSettings();
    setSettings(loadedSettings);
  }, []);

  // Return placeholder if ads are disabled
  if (!settings?.enableAds) {
    return null;
  }

  const adSizes = {
    banner: { width: 468, height: 60, minHeight: '60px' },
    rectangle: { width: 300, height: 250, minHeight: '250px' },
    skyscraper: { width: 160, height: 600, minHeight: '600px' },
    leaderboard: { width: 728, height: 90, minHeight: '90px' },
  };

  const size = adSizes[type];

  return (
    <div
      className={`relative bg-secondary/30 border border-border rounded-lg overflow-hidden ${className}`}
      style={{ minHeight: size.minHeight }}
    >
      {/* Clickadu Ad Code Placeholder */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center p-4">
          <p className="text-muted-foreground text-sm mb-2">إعلان</p>
          <div 
            className="bg-secondary border border-dashed border-border rounded flex items-center justify-center"
            style={{ width: size.width, height: size.height, maxWidth: '100%' }}
          >
            <span className="text-muted-foreground text-xs">
              Clickadu Ad Space
              <br />
              {size.width}x{size.height}
            </span>
          </div>
        </div>
      </div>

      {/* You would replace the above with actual Clickadu script */}
      {/* Example: */}
      {/* <script data-cfasync="false" async src="https://your-clickadu-code.js"></script> */}
      
      <div
        dangerouslySetInnerHTML={{
          __html: settings.clickaduCode || '',
        }}
      />
    </div>
  );
}
