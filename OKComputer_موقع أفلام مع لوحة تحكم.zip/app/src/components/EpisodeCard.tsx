import { Link } from 'react-router-dom';
import { Play, Clock, Star, Calendar } from 'lucide-react';
import type { Episode } from '@/types';
import tmdbService from '@/services/tmdb';
import { Badge } from '@/components/ui/badge';

interface EpisodeCardProps {
  episode: Episode;
  seriesId: string;
  seasonNumber: number;
  showThumbnail?: boolean;
}

export default function EpisodeCard({ 
  episode, 
  seriesId, 
  seasonNumber,
  showThumbnail = true 
}: EpisodeCardProps) {
  const imageUrl = episode.stillPath
    ? tmdbService.getImageUrl(episode.stillPath, 'w500')
    : '/placeholder-episode.jpg';

  const watchUrl = `/watch/series/${seriesId}/season/${seasonNumber}/episode/${episode.episodeNumber}`;

  return (
    <Link to={watchUrl} className="episode-card block group">
      <div className="flex gap-4 p-4 bg-card rounded-xl border border-border hover:border-primary/50 transition-all hover:shadow-lg hover:shadow-primary/5">
        {/* Episode Number / Thumbnail */}
        {showThumbnail ? (
          <div className="relative w-40 md:w-48 aspect-video rounded-lg overflow-hidden flex-shrink-0">
            <img
              src={imageUrl}
              alt={episode.name}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              loading="lazy"
            />
            
            {/* Play Overlay */}
            <div className="absolute inset-0 bg-background/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                <Play className="w-5 h-5 text-primary-foreground ml-0.5" />
              </div>
            </div>

            {/* Episode Number Badge */}
            <Badge className="absolute bottom-2 left-2 bg-primary text-primary-foreground border-0">
              الحلقة {episode.episodeNumber}
            </Badge>
          </div>
        ) : (
          <div className="w-16 h-16 bg-secondary rounded-lg flex items-center justify-center flex-shrink-0">
            <span className="text-2xl font-bold text-primary">{episode.episodeNumber}</span>
          </div>
        )}

        {/* Content */}
        <div className="flex-1 min-w-0">
          {/* Episode Title */}
          <h3 className="text-foreground font-semibold text-base mb-2 group-hover:text-primary transition-colors line-clamp-1">
            {episode.name}
          </h3>

          {/* Overview */}
          {episode.overview && (
            <p className="text-muted-foreground text-sm line-clamp-2 mb-3">
              {episode.overview}
            </p>
          )}

          {/* Meta */}
          <div className="flex flex-wrap items-center gap-4 text-sm">
            {episode.airDate && (
              <div className="flex items-center gap-1 text-muted-foreground">
                <Calendar className="w-4 h-4" />
                <span>{new Date(episode.airDate).toLocaleDateString('ar')}</span>
              </div>
            )}

            {episode.runtime && episode.runtime > 0 && (
              <div className="flex items-center gap-1 text-muted-foreground">
                <Clock className="w-4 h-4" />
                <span>{episode.runtime} دقيقة</span>
              </div>
            )}

            {episode.rating > 0 && (
              <div className="flex items-center gap-1 text-muted-foreground">
                <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                <span>{episode.rating.toFixed(1)}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
}
