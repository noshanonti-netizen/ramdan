import { useEffect } from 'react';
import localStorageService from '@/services/localStorage';

interface SEOProps {
  title: string;
  description?: string;
  keywords?: string[];
  image?: string;
  url?: string;
  type?: 'website' | 'article' | 'video.movie' | 'video.tv_show';
  publishedAt?: string;
  modifiedAt?: string;
  author?: string;
  noIndex?: boolean;
}

export default function SEO({
  title,
  description,
  keywords = [],
  image,
  url,
  type = 'website',
  publishedAt,
  modifiedAt,
  author,
  noIndex = false,
}: SEOProps) {
  useEffect(() => {
    const settings = localStorageService.getSettings();
    const siteName = settings.siteName || 'أفلاميكوز';
    const siteDescription = settings.siteDescription || 'أفضل موقع لمشاهدة الأفلام والمسلسلات';
    const siteKeywords = settings.siteKeywords || [];

    // Update page title
    document.title = title ? `${title} | ${siteName}` : siteName;

    // Update meta description
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', description || siteDescription);
    }

    // Update meta keywords
    const metaKeywords = document.querySelector('meta[name="keywords"]');
    const allKeywords = [...siteKeywords, ...keywords];
    if (metaKeywords) {
      metaKeywords.setAttribute('content', allKeywords.join(', '));
    } else if (allKeywords.length > 0) {
      const newMetaKeywords = document.createElement('meta');
      newMetaKeywords.name = 'keywords';
      newMetaKeywords.content = allKeywords.join(', ');
      document.head.appendChild(newMetaKeywords);
    }

    // Open Graph meta tags
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) {
      ogTitle.setAttribute('content', title || siteName);
    }

    const ogDescription = document.querySelector('meta[property="og:description"]');
    if (ogDescription) {
      ogDescription.setAttribute('content', description || siteDescription);
    }

    const ogImage = document.querySelector('meta[property="og:image"]');
    if (ogImage && image) {
      ogImage.setAttribute('content', image);
    }

    const ogUrl = document.querySelector('meta[property="og:url"]');
    if (ogUrl && url) {
      ogUrl.setAttribute('content', url);
    }

    const ogType = document.querySelector('meta[property="og:type"]');
    if (ogType) {
      ogType.setAttribute('content', type);
    }

    // Twitter Card meta tags
    const twitterTitle = document.querySelector('meta[name="twitter:title"]');
    if (twitterTitle) {
      twitterTitle.setAttribute('content', title || siteName);
    }

    const twitterDescription = document.querySelector('meta[name="twitter:description"]');
    if (twitterDescription) {
      twitterDescription.setAttribute('content', description || siteDescription);
    }

    const twitterImage = document.querySelector('meta[name="twitter:image"]');
    if (twitterImage && image) {
      twitterImage.setAttribute('content', image);
    }

    // Article meta tags (for content pages)
    if (type === 'article' || type === 'video.movie' || type === 'video.tv_show') {
      if (publishedAt) {
        const articlePublished = document.querySelector('meta[property="article:published_time"]');
        if (articlePublished) {
          articlePublished.setAttribute('content', publishedAt);
        }
      }

      if (modifiedAt) {
        const articleModified = document.querySelector('meta[property="article:modified_time"]');
        if (articleModified) {
          articleModified.setAttribute('content', modifiedAt);
        }
      }

      if (author) {
        const articleAuthor = document.querySelector('meta[property="article:author"]');
        if (articleAuthor) {
          articleAuthor.setAttribute('content', author);
        }
      }
    }

    // Canonical URL
    if (url) {
      let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
      if (!canonical) {
        canonical = document.createElement('link') as HTMLLinkElement;
        canonical.rel = 'canonical';
        document.head.appendChild(canonical);
      }
      canonical.setAttribute('href', url);
    }

    // Robots meta tag
    const robots = document.querySelector('meta[name="robots"]');
    if (robots) {
      robots.setAttribute('content', noIndex ? 'noindex, nofollow' : 'index, follow');
    } else {
      const newRobots = document.createElement('meta');
      newRobots.name = 'robots';
      newRobots.content = noIndex ? 'noindex, nofollow' : 'index, follow';
      document.head.appendChild(newRobots);
    }

    // Clean up on unmount
    return () => {
      // Reset to default values
      document.title = siteName;
      
      if (metaDescription) {
        metaDescription.setAttribute('content', siteDescription);
      }
    };
  }, [title, description, keywords, image, url, type, publishedAt, modifiedAt, author, noIndex]);

  return null;
}
