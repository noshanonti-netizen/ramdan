import { Link } from 'react-router-dom';
import { ChevronLeft, Calendar } from 'lucide-react';
import type { Season } from '@/types';
import tmdbService from '@/services/tmdb';
import { Badge } from '@/components/ui/badge';

interface SeasonCardProps {
  season: Season;
  seriesId: string;
  seriesName: string;
}

export default function SeasonCard({ season, seriesId, seriesName }: SeasonCardProps) {
  const imageUrl = season.posterPath
    ? tmdbService.getImageUrl(season.posterPath, 'w342')
    : '/placeholder-season.jpg';

  const seasonUrl = `/series/${seriesId}/season/${season.seasonNumber}`;

  return (
    <Link to={seasonUrl} className="season-card block group">
      <div className="bg-card rounded-xl border border-border overflow-hidden hover:border-primary/50 transition-all hover:shadow-lg hover:shadow-primary/5">
        <div className="flex flex-col md:flex-row">
          {/* Poster */}
          <div className="md:w-48 flex-shrink-0">
            <div className="aspect-[2/3] md:aspect-auto md:h-full relative overflow-hidden">
              <img
                src={imageUrl}
                alt={season.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                loading="lazy"
              />
              
              {/* Season Number Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent md:bg-gradient-to-r" />
              
              <div className="absolute bottom-4 left-4 md:bottom-auto md:top-4">
                <Badge className="bg-primary text-primary-foreground border-0 text-lg px-3 py-1">
                  الموسم {season.seasonNumber}
                </Badge>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 p-6">
            {/* Series Name */}
            <p className="text-muted-foreground text-sm mb-1">{seriesName}</p>

            {/* Season Title */}
            <h3 className="text-foreground font-bold text-xl md:text-2xl mb-3 group-hover:text-primary transition-colors">
              {season.name}
            </h3>

            {/* Overview */}
            {season.overview && (
              <p className="text-muted-foreground text-sm line-clamp-3 mb-4">
                {season.overview}
              </p>
            )}

            {/* Meta */}
            <div className="flex flex-wrap items-center gap-4 text-sm mb-4">
              {season.airDate && (
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Calendar className="w-4 h-4" />
                  <span>{new Date(season.airDate).toLocaleDateString('ar')}</span>
                </div>
              )}

              <div className="flex items-center gap-1 text-muted-foreground">
                <Film className="w-4 h-4" />
                <span>{season.episodeCount} حلقة</span>
              </div>
            </div>

            {/* View Episodes Button */}
            <div className="flex items-center gap-2 text-primary font-medium group-hover:gap-3 transition-all">
              <span>عرض الحلقات</span>
              <ChevronLeft className="w-5 h-5" />
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}
