import { AlertCircle, RefreshCw, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

interface ErrorProps {
  message?: string;
  code?: number;
  onRetry?: () => void;
  showHomeButton?: boolean;
}

export default function Error({ 
  message = 'حدث خطأ ما، يرجى المحاولة مرة أخرى', 
  code,
  onRetry,
  showHomeButton = true 
}: ErrorProps) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[50vh] py-12 px-4">
      <div className="text-center max-w-md">
        {/* Error Icon */}
        <div className="w-24 h-24 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-6">
          <AlertCircle className="w-12 h-12 text-destructive" />
        </div>

        {/* Error Code */}
        {code && (
          <h2 className="text-6xl font-bold text-destructive mb-2">
            {code}
          </h2>
        )}

        {/* Title */}
        <h3 className="text-2xl font-semibold text-foreground mb-4">
          عذراً، حدث خطأ
        </h3>

        {/* Message */}
        <p className="text-muted-foreground mb-8 leading-relaxed">
          {message}
        </p>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          {onRetry && (
            <Button
              onClick={onRetry}
              variant="outline"
              className="gap-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground"
            >
              <RefreshCw className="w-4 h-4" />
              إعادة المحاولة
            </Button>
          )}
          
          {showHomeButton && (
            <Link to="/">
              <Button className="gap-2">
                <Home className="w-4 h-4" />
                العودة للرئيسية
              </Button>
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}

// Not Found Component
export function NotFound({ 
  message = 'الصفحة التي تبحث عنها غير موجودة',
  itemType = 'الصفحة'
}: { 
  message?: string;
  itemType?: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[50vh] py-12 px-4">
      <div className="text-center max-w-md">
        {/* 404 Icon */}
        <div className="w-32 h-32 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
          <span className="text-6xl font-bold text-primary">404</span>
        </div>

        {/* Title */}
        <h2 className="text-3xl font-bold text-foreground mb-4">
          {itemType} غير موجودة
        </h2>

        {/* Message */}
        <p className="text-muted-foreground mb-8 leading-relaxed">
          {message}
        </p>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link to="/">
            <Button className="gap-2">
              <Home className="w-4 h-4" />
              العودة للرئيسية
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
