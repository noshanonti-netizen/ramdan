import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from '@/context/AuthContext';
import { ContentProvider } from '@/context/ContentContext';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import SEO from '@/components/SEO';

// Pages
import Home from '@/pages/Home';
import Movies from '@/pages/Movies';
import Series from '@/pages/Series';
import MovieDetails from '@/pages/MovieDetails';
import SeriesDetails from '@/pages/SeriesDetails';
import Seasons from '@/pages/Seasons';
import Episodes from '@/pages/Episodes';
import Watch from '@/pages/Watch';
import Search from '@/pages/Search';
import Category from '@/pages/Category';
import Login from '@/pages/Login';
import Admin from '@/pages/Admin';
import Settings from '@/pages/Settings';

function App() {
  return (
    <AuthProvider>
      <ContentProvider>
        <Router>
          <div className="min-h-screen bg-background">
            <SEO 
              title="أفلاميكوز"
              description="أفلاميكوز - أفضل موقع لمشاهدة الأفلام والمسلسلات العربية والأجنبية المترجمة بجودة عالية"
              keywords={['أفلام', 'مسلسلات', 'أفلام اون لاين', 'مسلسلات اون لاين', 'مشاهدة', 'تحميل', 'سينما', 'فيلم']}
              type="website"
            />
            <Navbar />
            
            <main className="pt-16 md:pt-20">
              <Routes>
                {/* Home */}
                <Route path="/" element={<Home />} />
                
                {/* Movies */}
                <Route path="/movies" element={<Movies />} />
                <Route path="/movie/:id" element={<MovieDetails />} />
                
                {/* Series */}
                <Route path="/series" element={<Series />} />
                <Route path="/series/:id" element={<SeriesDetails />} />
                <Route path="/series/:id/seasons" element={<Seasons />} />
                <Route path="/series/:id/season/:seasonNumber" element={<Episodes />} />
                
                {/* Watch */}
                <Route path="/watch/movie/:id" element={<Watch type="movie" />} />
                <Route path="/watch/series/:id/season/:seasonNumber/episode/:episodeNumber" element={<Watch type="series" />} />
                
                {/* Search */}
                <Route path="/search" element={<Search />} />
                
                {/* Category */}
                <Route path="/category/:type/:slug" element={<Category />} />
                
                {/* Auth */}
                <Route path="/login" element={<Login />} />
                
                {/* Admin */}
                <Route path="/admin/*" element={<Admin />} />
                
                {/* Settings */}
                <Route path="/settings" element={<Settings />} />
                
                {/* Redirect */}
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </main>
            
            <Footer />
          </div>
        </Router>
      </ContentProvider>
    </AuthProvider>
  );
}

export default App;
