import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import type { Movie, Series, Season, Episode, Genre, ContentContextType, SearchFilters } from '@/types';
import localStorageService from '@/services/localStorage';
import tmdbService from '@/services/tmdb';

const ContentContext = createContext<ContentContextType | undefined>(undefined);

export function ContentProvider({ children }: { children: ReactNode }) {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [series, setSeries] = useState<Series[]>([]);
  const [genres, setGenres] = useState<Genre[]>([]);
  const [loading, setLoading] = useState(true);

  // Load data from localStorage on mount
  useEffect(() => {
    const loadData = () => {
      setLoading(true);
      try {
        const loadedMovies = localStorageService.getMovies();
        const loadedSeries = localStorageService.getSeries();
        const loadedGenres = localStorageService.getGenres();
        
        setMovies(loadedMovies);
        setSeries(loadedSeries);
        setGenres(loadedGenres);
      } catch (error) {
        console.error('Error loading content data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  // Save data to localStorage whenever state changes
  useEffect(() => {
    if (movies.length > 0) {
      localStorageService.saveMovies(movies);
    }
  }, [movies]);

  useEffect(() => {
    if (series.length > 0) {
      localStorageService.saveSeries(series);
    }
  }, [series]);

  // Movie operations
  const addMovie = useCallback((movie: Movie) => {
    setMovies(prev => [...prev, movie]);
  }, []);

  const updateMovie = useCallback((id: string, updates: Partial<Movie>) => {
    setMovies(prev => prev.map(m => m.id === id ? { ...m, ...updates, updatedAt: new Date().toISOString() } : m));
  }, []);

  const deleteMovie = useCallback((id: string) => {
    setMovies(prev => prev.filter(m => m.id !== id));
  }, []);

  // Series operations
  const addSeries = useCallback((seriesItem: Series) => {
    setSeries(prev => [...prev, seriesItem]);
  }, []);

  const updateSeries = useCallback((id: string, updates: Partial<Series>) => {
    setSeries(prev => prev.map(s => s.id === id ? { ...s, ...updates, updatedAt: new Date().toISOString() } : s));
  }, []);

  const deleteSeries = useCallback((id: string) => {
    setSeries(prev => prev.filter(s => s.id !== id));
  }, []);

  // Season operations
  const addSeason = useCallback((season: Season) => {
    localStorageService.addSeason(season);
  }, []);

  const updateSeason = useCallback((id: string, updates: Partial<Season>) => {
    localStorageService.updateSeason(id, updates);
  }, []);

  const deleteSeason = useCallback((id: string) => {
    localStorageService.deleteSeason(id);
  }, []);

  // Episode operations
  const addEpisode = useCallback((episode: Episode) => {
    localStorageService.addEpisode(episode);
  }, []);

  const updateEpisode = useCallback((id: string, updates: Partial<Episode>) => {
    localStorageService.updateEpisode(id, updates);
  }, []);

  const deleteEpisode = useCallback((id: string) => {
    localStorageService.deleteEpisode(id);
  }, []);

  // Fetch featured content
  const fetchFeaturedContent = useCallback(async () => {
    try {
      const featuredMovies = localStorageService.getFeaturedMovies();
      const featuredSeries = localStorageService.getFeaturedSeries();
      return [...featuredMovies, ...featuredSeries];
    } catch (error) {
      console.error('Error fetching featured content:', error);
      return [];
    }
  }, []);

  // Search content
  const searchContent = useCallback((filters: SearchFilters): (Movie | Series)[] => {
    const { query, type, genres, year, sortBy } = filters;
    let results: (Movie | Series)[] = [];

    // Filter by type
    if (type === 'all' || type === 'movie') {
      results = [...results, ...movies];
    }
    if (type === 'all' || type === 'series') {
      results = [...results, ...series];
    }

    // Filter by search query
    if (query) {
      const lowerQuery = query.toLowerCase();
      results = results.filter(item => {
        const title = 'title' in item ? item.title : item.name;
        const overview = item.overview;
        return title.toLowerCase().includes(lowerQuery) || 
               overview.toLowerCase().includes(lowerQuery) ||
               item.genres.some(g => g.toLowerCase().includes(lowerQuery));
      });
    }

    // Filter by genres
    if (genres && genres.length > 0) {
      results = results.filter(item => 
        item.genres.some(g => genres.includes(g))
      );
    }

    // Filter by year
    if (year) {
      results = results.filter(item => {
        const date = 'releaseDate' in item ? item.releaseDate : item.firstAirDate;
        return date && date.startsWith(year);
      });
    }

    // Sort results
    switch (sortBy) {
      case 'rating':
        results.sort((a, b) => b.rating - a.rating);
        break;
      case 'date':
        results.sort((a, b) => {
          const dateA = 'releaseDate' in a ? a.releaseDate : a.firstAirDate;
          const dateB = 'releaseDate' in b ? b.releaseDate : b.firstAirDate;
          return new Date(dateB).getTime() - new Date(dateA).getTime();
        });
        break;
      case 'title':
        results.sort((a, b) => {
          const titleA = 'title' in a ? a.title : a.name;
          const titleB = 'title' in b ? b.title : b.name;
          return titleA.localeCompare(titleB, 'ar');
        });
        break;
      default:
        results.sort((a, b) => b.rating - a.rating);
    }

    return results;
  }, [movies, series]);

  // Import from TMDB - implemented in tmdb service

  const value: ContentContextType = {
    movies,
    series,
    genres,
    featuredContent: [],
    loading,
    addMovie,
    updateMovie,
    deleteMovie,
    addSeries,
    updateSeries,
    deleteSeries,
    addSeason,
    updateSeason,
    deleteSeason,
    addEpisode,
    updateEpisode,
    deleteEpisode,
    fetchFeaturedContent,
    searchContent,
  };

  return <ContentContext.Provider value={value}>{children}</ContentContext.Provider>;
}

export function useContent(): ContentContextType {
  const context = useContext(ContentContext);
  if (context === undefined) {
    throw new Error('useContent must be used within a ContentProvider');
  }
  return context;
}
