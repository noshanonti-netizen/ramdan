// API Types from TMDB
export interface TMDBMovie {
  id: number;
  title: string;
  overview: string;
  poster_path: string;
  backdrop_path: string;
  release_date: string;
  vote_average: number;
  vote_count: number;
  genre_ids: number[];
  adult: boolean;
  original_language: string;
  original_title: string;
  popularity: number;
  video: boolean;
}

export interface TMDBSeries {
  id: number;
  name: string;
  overview: string;
  poster_path: string;
  backdrop_path: string;
  first_air_date: string;
  vote_average: number;
  vote_count: number;
  genre_ids: number[];
  adult: boolean;
  original_language: string;
  original_name: string;
  popularity: number;
  origin_country: string[];
  original_country: string[];
}

export interface TMDBGenre {
  id: number;
  name: string;
}

export interface TMDBCast {
  id: number;
  name: string;
  character?: string;
  profile_path: string | null;
  order: number;
}

export interface TMDBCrew {
  id: number;
  name: string;
  job: string;
  department: string;
  profile_path: string | null;
}

export interface TMDBSeason {
  id: number;
  name: string;
  overview: string;
  poster_path: string | null;
  season_number: number;
  air_date: string;
  episode_count: number;
}

export interface TMDBEpisode {
  id: number;
  name: string;
  overview: string;
  still_path: string | null;
  episode_number: number;
  air_date: string;
  runtime: number;
  vote_average: number;
  vote_count: number;
}

export interface TMDBVideo {
  id: string;
  key: string;
  name: string;
  site: string;
  size: number;
  type: string;
  official: boolean;
  published_at: string;
}

// App Types
export interface Movie {
  id: string;
  tmdbId: number;
  title: string;
  overview: string;
  posterPath: string;
  backdropPath: string;
  releaseDate: string;
  rating: number;
  voteCount: number;
  genres: string[];
  cast: Cast[];
  crew: Crew[];
  videos: Video[];
  runtime: number;
  tagline: string;
  homepage: string;
  imdbId: string;
  status: string;
  budget: number;
  revenue: number;
  createdAt: string;
  updatedAt: string;
  isFeatured?: boolean;
}

export interface Series {
  id: string;
  tmdbId: number;
  name: string;
  overview: string;
  posterPath: string;
  backdropPath: string;
  firstAirDate: string;
  rating: number;
  voteCount: number;
  genres: string[];
  cast: Cast[];
  crew: Crew[];
  videos: Video[];
  numberOfSeasons: number;
  numberOfEpisodes: number;
  homepage: string;
  imdbId: string;
  status: string;
  tagline: string;
  createdAt: string;
  updatedAt: string;
  isFeatured?: boolean;
}

export interface Season {
  id: string;
  seriesId: string;
  seasonNumber: number;
  name: string;
  overview: string;
  posterPath: string;
  airDate: string;
  episodeCount: number;
  episodes: Episode[];
  createdAt: string;
  updatedAt: string;
}

export interface Episode {
  id: string;
  seasonId: string;
  episodeNumber: number;
  name: string;
  overview: string;
  stillPath: string;
  airDate: string;
  runtime: number;
  rating: number;
  voteCount: number;
  videos: Video[];
  createdAt: string;
  updatedAt: string;
}

export interface Cast {
  id: number;
  name: string;
  character?: string;
  profilePath: string | null;
  order: number;
}

export interface Crew {
  id: number;
  name: string;
  job: string;
  department: string;
  profilePath: string | null;
}

export interface Video {
  id: string;
  key: string;
  name: string;
  site: string;
  type: string;
  official: boolean;
  publishedAt: string;
}

export interface Genre {
  id: string;
  name: string;
  slug: string;
  type: 'movie' | 'series' | 'both';
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  createdAt: string;
}

export interface User {
  id: string;
  username: string;
  email: string;
  role: 'admin' | 'user';
  createdAt: string;
}

export interface ApiKey {
  id: string;
  key: string;
  name: string;
  isActive: boolean;
  createdAt: string;
}

export interface AppSettings {
  tmdbApiKey: string;
  siteName: string;
  siteDescription: string;
  siteKeywords: string[];
  enableAds: boolean;
  clickaduCode: string;
  primaryColor: string;
  enableRegistration: boolean;
}

// API Response Types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
}

export interface PaginatedResponse<T> {
  page: number;
  results: T[];
  total_pages: number;
  total_results: number;
}

// Form Types
export interface MovieFormData {
  tmdbId: string;
  isFeatured: boolean;
  customPoster?: File;
  customBackdrop?: File;
}

export interface SeriesFormData {
  tmdbId: string;
  isFeatured: boolean;
  customPoster?: File;
  customBackdrop?: File;
}

export interface EpisodeFormData {
  seasonId: string;
  episodeNumber: number;
  videoUrl?: string;
}

// Search Types
export interface SearchFilters {
  query: string;
  type: 'all' | 'movie' | 'series';
  genres: string[];
  year: string;
  sortBy: string;
  page: number;
}

// Context Types
export interface AppContextType {
  settings: AppSettings | null;
  updateSettings: (settings: Partial<AppSettings>) => void;
  isLoading: boolean;
}

export interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
}

export interface ContentContextType {
  movies: Movie[];
  series: Series[];
  genres: Genre[];
  featuredContent: (Movie | Series)[];
  loading: boolean;
  addMovie: (movie: Movie) => void;
  updateMovie: (id: string, movie: Partial<Movie>) => void;
  deleteMovie: (id: string) => void;
  addSeries: (series: Series) => void;
  updateSeries: (id: string, series: Partial<Series>) => void;
  deleteSeries: (id: string) => void;
  addSeason: (season: Season) => void;
  updateSeason: (id: string, season: Partial<Season>) => void;
  deleteSeason: (id: string) => void;
  addEpisode: (episode: Episode) => void;
  updateEpisode: (id: string, episode: Partial<Episode>) => void;
  deleteEpisode: (id: string) => void;
  fetchFeaturedContent: () => void;
  searchContent: (filters: SearchFilters) => (Movie | Series)[];
}
